import os
from datetime import datetime
from app import db
import json
from enum import Enum

class TaskStatus(Enum):
    DRAFT = "draft"
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"

class Project(db.Model):
    __tablename__ = 'projects'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    created_date = db.Column(db.DateTime, default=datetime.utcnow)
    updated_date = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    pages = db.relationship('Page', back_populates='project', cascade='all, delete-orphan')
    tasks = db.relationship('Task', back_populates='project', cascade='all, delete-orphan')
    prompts = db.relationship('Prompt', back_populates='project', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Project {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'created_date': self.created_date.isoformat(),
            'updated_date': self.updated_date.isoformat(),
            'page_count': len(self.pages),
            'task_count': len(self.tasks)
        }
    
    def get_progress_stats(self):
        """Get project progress statistics"""
        total_tasks = len(self.tasks)
        if total_tasks == 0:
            return {
                'draft': 0,
                'in_progress': 0,
                'complete': 0,
                'total': 0,
                'percent_complete': 0
            }
        
        draft_count = sum(1 for task in self.tasks if task.work_status == TaskStatus.DRAFT.value)
        in_progress_count = sum(1 for task in self.tasks if task.work_status == TaskStatus.IN_PROGRESS.value)
        complete_count = sum(1 for task in self.tasks if task.work_status == TaskStatus.COMPLETE.value)
        
        return {
            'draft': draft_count,
            'in_progress': in_progress_count,
            'complete': complete_count,
            'total': total_tasks,
            'percent_complete': (complete_count / total_tasks) * 100 if total_tasks > 0 else 0
        }

class Page(db.Model):
    __tablename__ = 'pages'
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=False)
    page_number = db.Column(db.Integer, nullable=False)
    notes = db.Column(db.Text)
    created_date = db.Column(db.DateTime, default=datetime.utcnow)
    updated_date = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    selected_task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable=True)
    
    # Relationships
    project = db.relationship('Project', back_populates='pages')
    images = db.relationship('Image', back_populates='page', cascade='all, delete-orphan')
    tasks = db.relationship('Task', back_populates='page', cascade='all, delete-orphan', 
                          foreign_keys='[Task.page_id]')
    selected_task = db.relationship('Task', foreign_keys=[selected_task_id])
    
    __table_args__ = (
        db.UniqueConstraint('project_id', 'page_number', name='unique_page_number_per_project'),
    )
    
    def __repr__(self):
        return f'<Page {self.page_number} of Project {self.project_id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'project_id': self.project_id,
            'page_number': self.page_number,
            'notes': self.notes,
            'created_date': self.created_date.isoformat(),
            'updated_date': self.updated_date.isoformat(),
            'image_count': len(self.images),
            'task_count': len(self.tasks),
            'selected_task_id': self.selected_task_id
        }

    def get_dictionary_entries(self):
        """Get dictionary entries for this page from the selected task or latest task"""
        from app.models.models import DictionaryEntry, ProcessingResult
        
        if self.selected_task_id:
            # Get entries from selected task
            result = ProcessingResult.query.filter_by(task_id=self.selected_task_id).first()
            if result:
                return DictionaryEntry.query.filter_by(processing_result_id=result.id).all()
        
        # If no selected task or no entries found, get from latest task
        latest_task = sorted(self.tasks, key=lambda t: t.start_time, reverse=True)[0] if self.tasks else None
        if latest_task:
            result = ProcessingResult.query.filter_by(task_id=latest_task.id).first()
            if result:
                return DictionaryEntry.query.filter_by(processing_result_id=result.id).all()
        
        return []

class Image(db.Model):
    __tablename__ = 'images'
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    original_filename = db.Column(db.String(255), nullable=False)
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)
    file_size = db.Column(db.Integer)
    mime_type = db.Column(db.String(100))
    width = db.Column(db.Integer)
    height = db.Column(db.Integer)
    dpi = db.Column(db.Integer)
    notes = db.Column(db.Text)
    page_number = db.Column(db.Integer)
    page_id = db.Column(db.Integer, db.ForeignKey('pages.id'))
    
    # Relationships
    processing_results = db.relationship('ProcessingResult', back_populates='image', cascade='all, delete-orphan')
    tasks = db.relationship('Task', back_populates='image', cascade='all, delete-orphan')
    page = db.relationship('Page', back_populates='images')
    
    def __repr__(self):
        return f'<Image {self.original_filename}>'
    
    @property
    def file_path(self):
        """Return the absolute path to the image file."""
        from flask import current_app
        import os
        return os.path.join(current_app.config['UPLOAD_FOLDER'], self.filename)
    
    def to_dict(self):
        return {
            'id': self.id,
            'filename': self.filename,
            'original_filename': self.original_filename,
            'upload_date': self.upload_date.isoformat(),
            'file_size': self.file_size,
            'mime_type': self.mime_type,
            'width': self.width,
            'height': self.height,
            'dpi': self.dpi,
            'notes': self.notes,
            'page_number': self.page_number,
            'page_id': self.page_id
        }

class Prompt(db.Model):
    __tablename__ = 'prompts'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    content = db.Column(db.Text, nullable=False)
    model = db.Column(db.String(50), default='claude-3-opus-20240229')
    max_tokens = db.Column(db.Integer, default=5000)
    enable_thinking = db.Column(db.Boolean, default=True)
    temperature = db.Column(db.Float, default=0)
    created_date = db.Column(db.DateTime, default=datetime.utcnow)
    updated_date = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id', name='fk_prompt_project'))
    
    # Relationships
    processing_results = db.relationship('ProcessingResult', back_populates='prompt', cascade='all, delete-orphan')
    tasks = db.relationship('Task', back_populates='prompt', cascade='all, delete-orphan')
    project = db.relationship('Project', back_populates='prompts')
    
    def __repr__(self):
        return f'<Prompt {self.name}>'
    
    def validate(self):
        """Validate prompt settings"""
        if self.enable_thinking and self.temperature != 1.0:
            raise ValueError("Temperature must be set to 1.0 when thinking is enabled")
        return True
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'content': self.content,
            'model': self.model,
            'max_tokens': self.max_tokens,
            'enable_thinking': self.enable_thinking,
            'temperature': self.temperature,
            'created_date': self.created_date.isoformat(),
            'updated_date': self.updated_date.isoformat()
        }

class Task(db.Model):
    __tablename__ = 'tasks'
    id = db.Column(db.Integer, primary_key=True)
    task_type = db.Column(db.String(50), nullable=False)  # e.g., 'image_processing'
    status = db.Column(db.String(20), nullable=False)  # queued, running, completed, failed
    work_status = db.Column(db.String(20), default=TaskStatus.DRAFT.value)  # draft, in_progress, complete
    progress = db.Column(db.Integer, default=0)  # 0-100
    start_time = db.Column(db.DateTime, default=datetime.utcnow)
    end_time = db.Column(db.DateTime)
    error = db.Column(db.Text)
    log = db.Column(db.Text, default='[]')  # JSON string array of log entries
    task_metadata = db.Column(db.Text)  # JSON string with task-specific metadata
    
    # Foreign keys
    image_id = db.Column(db.Integer, db.ForeignKey('images.id'))
    prompt_id = db.Column(db.Integer, db.ForeignKey('prompts.id'))
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'))
    page_id = db.Column(db.Integer, db.ForeignKey('pages.id'))
    
    # Relationships
    image = db.relationship('Image', back_populates='tasks')
    prompt = db.relationship('Prompt', back_populates='tasks')
    processing_result = db.relationship('ProcessingResult', back_populates='task', uselist=False)
    project = db.relationship('Project', back_populates='tasks')
    page = db.relationship('Page', back_populates='tasks', foreign_keys=[page_id])
    
    def __repr__(self):
        return f'<Task {self.id}: {self.task_type} - {self.status}>'
    
    def get_duration(self):
        """Calculate the duration of the task"""
        if not self.end_time and (self.status == 'running' or self.status == 'queued'):
            return datetime.utcnow() - self.start_time
        elif self.end_time:
            return self.end_time - self.start_time
        return None
    
    def format_duration(self):
        """Format the duration in HH:mm:ss format"""
        duration = self.get_duration()
        if not duration:
            return None
        
        # Calculate total seconds
        total_seconds = int(duration.total_seconds())
        
        # Calculate hours, minutes, and seconds
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        # Format as HH:mm:ss
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    
    def update_status(self, status, log_entry=None, progress=None, error=None):
        """Update the task status and add a log entry"""
        self.status = status
        
        # Update progress if provided
        if progress is not None:
            self.progress = progress
        
        # Add log entry if provided
        if log_entry:
            try:
                log_entries = json.loads(self.log or '[]')
            except:
                log_entries = []
            
            timestamp = datetime.utcnow().isoformat()
            log_entries.append({
                'timestamp': timestamp,
                'message': log_entry,
                'status': status,
                'progress': self.progress
            })
            self.log = json.dumps(log_entries)
        
        # Update error if provided
        if error:
            self.error = error
        
        # Set end time if task is completed or failed
        if status in ['completed', 'failed']:
            self.end_time = datetime.utcnow()
        
        # Commit the changes
        db.session.commit()
    
    def update_work_status(self, work_status):
        """Update the work status of the task"""
        if work_status in [status.value for status in TaskStatus]:
            self.work_status = work_status
            db.session.commit()
    
    def get_log_entries(self):
        """Get log entries as a list of dictionaries"""
        try:
            return json.loads(self.log or '[]')
        except:
            return []
    
    def get_metadata_dict(self):
        """Get metadata as a dictionary"""
        try:
            return json.loads(self.task_metadata or '{}')
        except:
            return {}
    
    def is_active(self):
        """Check if the task is active (queued or running)"""
        return self.status in ['queued', 'running']
    
    def to_dict(self):
        """Convert task to dictionary"""
        duration = self.get_duration()
        duration_str = self.format_duration() if duration else None
        
        result = {
            'id': self.id,
            'task_type': self.task_type,
            'status': self.status,
            'work_status': self.work_status,
            'progress': self.progress,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'duration': duration_str,
            'error': self.error,
            'log_entries': self.get_log_entries(),
            'metadata': self.get_metadata_dict(),
            'image_id': self.image_id,
            'prompt_id': self.prompt_id,
            'project_id': self.project_id,
            'page_id': self.page_id,
            'image_name': self.image.original_filename if self.image else None,
            'prompt_name': self.prompt.name if self.prompt else None
        }
        
        if self.project:
            result['project_name'] = self.project.name
        
        if self.page:
            result['page_number'] = self.page.page_number
            
        return result

class ProcessingResult(db.Model):
    __tablename__ = 'processing_results'
    id = db.Column(db.Integer, primary_key=True)
    image_id = db.Column(db.Integer, db.ForeignKey('images.id'), nullable=False)
    prompt_id = db.Column(db.Integer, db.ForeignKey('prompts.id'), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    raw_response = db.Column(db.Text)
    thinking_content = db.Column(db.Text)
    num_entries = db.Column(db.Integer, default=0)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'))
    
    # Relationships
    image = db.relationship('Image', back_populates='processing_results')
    prompt = db.relationship('Prompt', back_populates='processing_results')
    dictionary_entries = db.relationship('DictionaryEntry', back_populates='processing_result', cascade='all, delete-orphan')
    task = db.relationship('Task', back_populates='processing_result')
    
    def __repr__(self):
        return f'<ProcessingResult {self.id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'image_id': self.image_id,
            'prompt_id': self.prompt_id,
            'timestamp': self.timestamp.isoformat(),
            'num_entries': self.num_entries,
            'task_id': self.task_id
        }

class DictionaryEntry(db.Model):
    __tablename__ = 'dictionary_entries'
    id = db.Column(db.Integer, primary_key=True)
    processing_result_id = db.Column(db.Integer, db.ForeignKey('processing_results.id'), nullable=False)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=True)
    page_id = db.Column(db.Integer, db.ForeignKey('pages.id'), nullable=True)
    estonian_headword = db.Column(db.String(255))
    estonian_synonyms = db.Column(db.Text)
    german_equivalent = db.Column(db.String(255))
    german_synonyms = db.Column(db.Text)
    latin_explanation = db.Column(db.Text)
    part_of_speech = db.Column(db.String(50))
    estonian_declension = db.Column(db.Text)
    estonian_mwu = db.Column(db.Text)
    translated_mwu = db.Column(db.Text)
    order = db.Column(db.Integer, default=0)
    
    # Evaluation fields
    is_evaluated = db.Column(db.Boolean, default=False)
    is_correct = db.Column(db.Boolean, default=None)
    evaluated_at = db.Column(db.DateTime)
    
    # Modification tracking fields
    is_user_added = db.Column(db.Boolean, default=False)
    is_user_modified = db.Column(db.Boolean, default=False)
    last_modified_at = db.Column(db.DateTime)
    
    # Relationships
    processing_result = db.relationship('ProcessingResult', back_populates='dictionary_entries')
    project = db.relationship('Project', backref=db.backref('dictionary_entries', lazy='dynamic'))
    page = db.relationship('Page', backref=db.backref('dictionary_entries', lazy='dynamic'))
    
    def __repr__(self):
        return f'<DictionaryEntry {self.id}: {self.estonian_headword}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'processing_result_id': self.processing_result_id,
            'project_id': self.project_id,
            'page_id': self.page_id,
            'estonian_headword': self.estonian_headword,
            'estonian_synonyms': self.estonian_synonyms,
            'german_equivalent': self.german_equivalent,
            'german_synonyms': self.german_synonyms,
            'latin_explanation': self.latin_explanation,
            'part_of_speech': self.part_of_speech,
            'estonian_declension': self.estonian_declension,
            'estonian_mwu': self.estonian_mwu,
            'translated_mwu': self.translated_mwu,
            'order': self.order,
            'is_evaluated': self.is_evaluated,
            'is_correct': self.is_correct,
            'evaluated_at': self.evaluated_at.isoformat() if self.evaluated_at else None,
            'is_user_added': self.is_user_added,
            'is_user_modified': self.is_user_modified,
            'last_modified_at': self.last_modified_at.isoformat() if self.last_modified_at else None
        } 