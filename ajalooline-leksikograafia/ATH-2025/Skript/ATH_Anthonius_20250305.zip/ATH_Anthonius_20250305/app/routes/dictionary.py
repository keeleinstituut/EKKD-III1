import os
import json
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, current_app, send_file
from app import db
from app.models.models import Image, Prompt, ProcessingResult, DictionaryEntry, Task, Page, Project
from app.utils.parser import ParserWrapper
import pandas as pd
import io
import csv
from io import StringIO
import base64
import re
import requests
import threading
from datetime import datetime  # Import datetime class from datetime module

dictionary_bp = Blueprint('dictionary', __name__, url_prefix='/dictionary')

@dictionary_bp.route('/')
def index():
    """List all processing results."""
    results = ProcessingResult.query.order_by(ProcessingResult.timestamp.desc()).all()
    return render_template('dictionary/index.html', results=results)

@dictionary_bp.route('/process', methods=['GET', 'POST'])
def process():
    """Process an image using a selected prompt"""
    images = Image.query.all()
    prompts = Prompt.query.all()
    projects = Project.query.order_by(Project.name).all()
    
    # Get selected image and prompt from query params
    selected_image_id = request.args.get('image_id', type=int)
    selected_prompt_id = request.args.get('prompt_id', type=int)
    page_number = request.args.get('page_number', 1, type=int)
    project_id = request.args.get('project_id', type=int)
    page_id = request.args.get('page_id', type=int)
    
    if request.method == 'POST':
        # Get form data
        image_id = request.form.get('image_id', type=int)
        prompt_id = request.form.get('prompt_id', type=int)
        page_number = request.form.get('page_number', 1, type=int)
        project_id = request.form.get('project_id', type=int)
        page_id = request.form.get('page_id', type=int)
        api_key = request.form.get('api_key', '')
        
        # Validate inputs
        if not image_id:
            flash('Please select an image to process.', 'danger')
            return redirect(url_for('dictionary.process'))
            
        if not prompt_id:
            flash('Please select a prompt to use.', 'danger')
            return redirect(url_for('dictionary.process'))
            
        if not api_key:
            flash('API key is required.', 'danger')
            return redirect(url_for('dictionary.process'))
        
        # Retrieve the selected image and prompt
        image = Image.query.get_or_404(image_id)
        prompt = Prompt.query.get_or_404(prompt_id)
        
        # If page_id is provided, get the associated project
        if page_id and not project_id:
            page = Page.query.get(page_id)
            if page:
                project_id = page.project_id
        
        # Create a new task for the processing
        task = Task(
            task_type="image_processing",
            status="queued",
            image_id=image_id,
            prompt_id=prompt_id,
            project_id=project_id,
            page_id=page_id,
            progress=0,
            task_metadata=json.dumps({
                'page_number': page_number,
                'model': prompt.model,
                'max_tokens': prompt.max_tokens,
                'enable_thinking': prompt.enable_thinking
            })
        )
        db.session.add(task)
        db.session.commit()
        
        # Start processing in a background thread
        thread = threading.Thread(
            target=process_image_thread,
            args=(current_app._get_current_object(), image, prompt, page_number, api_key, task.id)
        )
        thread.daemon = True
        thread.start()
        
        flash(f'Processing started for image "{image.original_filename}" with prompt "{prompt.name}". You can monitor progress in the Tasks section.', 'success')
        return redirect(url_for('tasks.view', task_id=task.id))
    
    return render_template(
        'dictionary/process.html',
        images=images,
        prompts=prompts,
        projects=projects,
        selected_image_id=selected_image_id,
        selected_prompt_id=selected_prompt_id,
        page_number=page_number,
        project_id=project_id,
        page_id=page_id
    )

def process_image_thread(app, image, prompt, page_number, api_key, task_id):
    """Background thread to process an image"""
    with app.app_context():
        # Don't use Task.update_status() since it uses db.session directly
        # Instead, we'll manage our own session and update the task directly
        
        session = db.session
        
        # Helper function to update task status within our session
        def update_task_status(status, message=None, progress=None, error=None):
            # First, get a fresh task instance
            task = session.get(Task, task_id)
            if not task:
                return
                
            task.status = status
            
            if progress is not None:
                task.progress = progress
                
            if message:
                try:
                    log_entries = json.loads(task.log or '[]')
                except:
                    log_entries = []
                
                timestamp = datetime.utcnow().isoformat()
                log_entries.append({
                    'timestamp': timestamp,
                    'message': message,
                    'status': status,
                    'progress': task.progress
                })
                task.log = json.dumps(log_entries)
            
            if error:
                task.error = error
                
            if status in ['completed', 'failed']:
                task.end_time = datetime.utcnow()
                
                # If task completed successfully and set_as_selected flag is True, set it as selected
                if status == 'completed' and task.page_id:
                    try:
                        metadata = json.loads(task.task_metadata or '{}')
                        if metadata.get('set_as_selected'):
                            page = session.get(Page, task.page_id)
                            if page:
                                page.selected_task_id = task.id
                    except:
                        pass  # If there's any error reading metadata or setting selected task, ignore it
            
            session.commit()
        
        try:
            # Get fresh copies of objects from the database
            task = session.get(Task, task_id)
            if not task:
                raise Exception(f"Task with ID {task_id} not found")
                
            # Start by updating the task status
            update_task_status(
                'running', 
                message="Initializing task processing...",
                progress=2
            )
            
            # Now load the other objects
            image_id = task.image_id
            prompt_id = task.prompt_id
            project_id = task.project_id
            page_id = task.page_id
            
            if not image_id:
                raise Exception("No image associated with this task")
            
            if not prompt_id:
                raise Exception("No prompt associated with this task")
            
            image = session.get(Image, image_id)
            if not image:
                raise Exception(f"Image with ID {image_id} not found")
                
            prompt = session.get(Prompt, prompt_id)
            if not prompt:
                raise Exception(f"Prompt with ID {prompt_id} not found")
            
            # Update task status to show we've loaded everything successfully
            update_task_status(
                'running', 
                message=f"Starting processing of image '{image.original_filename}' with prompt '{prompt.name}'",
                progress=5
            )
            
            # Get the image path
            image_path = os.path.join(
                os.path.abspath(os.path.dirname(__file__)), 
                '..', 'static', 'uploads', 
                image.filename
            )
            
            # Initialize the parser
            update_task_status(
                'running', 
                message=f"Initializing parser with model: {prompt.model}, thinking: {prompt.enable_thinking}, temperature: {prompt.temperature}",
                progress=10
            )
            
            # Read and encode image
            with open(image_path, 'rb') as file:
                image_content = file.read()
            base64_content = base64.b64encode(image_content).decode('utf-8')
            
            # Prepare API request
            headers = {
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
                "accept": "application/json"
            }
            
            data = {
                "model": prompt.model,
                "max_tokens": prompt.max_tokens,
                "stream": True,  # Enable streaming
                "system": prompt.content,
                "temperature": 1.0 if prompt.enable_thinking else prompt.temperature,  # Force temperature=1 if thinking enabled
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "media_type": "image/png",
                                    "data": base64_content
                                }
                            },
                            {
                                "type": "text",
                                "text": "Extract ALL entries exactly as they appear, maintaining their precise order within each column."
                            }
                        ]
                    }
                ]
            }
            
            # Add thinking if enabled
            if prompt.enable_thinking:
                thinking_budget = min(prompt.max_tokens // 2, 16000)
                if thinking_budget > 0:
                    data["thinking"] = {
                        "type": "enabled",
                        "budget_tokens": thinking_budget
                    }
            
            update_task_status(
                'running', 
                message=f"Sending image to Claude API for processing...",
                progress=20
            )
            
            # Make streaming API request
            response = requests.post(
                "https://api.anthropic.com/v1/messages",
                headers=headers,
                json=data,
                stream=True  # Enable streaming in requests
            )
            
            if response.status_code != 200:
                raise Exception(f"API error: {response.text}")
            
            # Initialize variables to store the complete response
            raw_content = ""
            thinking_content = None
            current_content_block = {"type": None, "text": ""}
            entries = []
            
            # Process the stream
            for line in response.iter_lines():
                if not line:
                    continue
                    
                # Remove "data: " prefix if present
                if line.startswith(b'data: '):
                    line = line[6:]
                
                try:
                    event_data = json.loads(line)
                    event_type = event_data.get('type')
                    
                    if event_type == 'content_block_delta':
                        delta = event_data.get('delta', {})
                        if delta.get('type') == 'text_delta':
                            # Accumulate text content
                            text = delta.get('text', '')
                            raw_content += text
                            update_task_status(
                                'running',
                                message=f"Received content: {text[:100]}{'...' if len(text) > 100 else ''}",
                                progress=50
                            )
                        elif delta.get('type') == 'thinking_delta':
                            # Accumulate thinking content
                            thinking = delta.get('thinking', '')
                            if thinking_content is None:
                                thinking_content = thinking
                            else:
                                thinking_content += thinking
                            update_task_status(
                                'running',
                                message=f"Thinking: {thinking[:100]}{'...' if len(thinking) > 100 else ''}",
                                progress=40
                            )
                    
                    elif event_type == 'message_stop':
                        update_task_status(
                            'running',
                            message="Finished receiving streaming response. Processing entries...",
                            progress=80
                        )
                        
                except json.JSONDecodeError:
                    continue
            
            # Parse entries from the complete raw_content
            try:
                # Use regex to find all JSON objects in the response
                json_pattern = r'\{[^{}]*\}'
                potential_entries = list(re.finditer(json_pattern, raw_content))
                
                for entry_match in potential_entries:
                    try:
                        entry_text = entry_match.group()
                        entry = json.loads(entry_text)
                        entries.append(entry)
                    except json.JSONDecodeError:
                        # Try to clean the text and parse again
                        try:
                            cleaned_text = entry_text.strip().replace('\n', '').replace('\r', '')
                            entry = json.loads(cleaned_text)
                            entries.append(entry)
                        except:
                            continue
            except Exception as e:
                update_task_status(
                    'running',
                    message=f"Warning: Error parsing some entries: {str(e)}",
                    progress=85
                )
            
            # Create a processing result
            result = ProcessingResult(
                image_id=image.id,
                prompt_id=prompt.id,
                raw_response=raw_content,
                thinking_content=thinking_content,
                num_entries=len(entries),
                task_id=task.id
            )
            session.add(result)
            session.commit()
            
            # Add dictionary entries to the database
            update_task_status(
                'running', 
                message=f"Storing {len(entries)} dictionary entries in the database...",
                progress=90
            )
            
            for entry_data in entries:
                entry = DictionaryEntry(
                    processing_result_id=result.id,
                    project_id=project_id,
                    page_id=page_id,
                    estonian_headword=entry_data.get('estonian_headword', ''),
                    estonian_synonyms=entry_data.get('estonian_synonyms', ''),
                    german_equivalent=entry_data.get('german_equivalent', ''),
                    german_synonyms=entry_data.get('german_synonyms', ''),
                    latin_explanation=entry_data.get('latin_explanation', ''),
                    part_of_speech=entry_data.get('part_of_speech', ''),
                    estonian_declension=entry_data.get('estonian_declension', ''),
                    estonian_mwu=entry_data.get('estonian_mwu', ''),
                    translated_mwu=entry_data.get('translated_mwu', '')
                )
                session.add(entry)
            
            session.commit()
            
            # Mark task as completed
            update_task_status(
                'completed', 
                message=f"Processing completed successfully. Extracted {len(entries)} dictionary entries.",
                progress=100
            )
            
        except Exception as e:
            # Update task status to failed
            update_task_status(
                'failed', 
                message=f"Error during processing: {str(e)}",
                error=str(e)
            )
        finally:
            # Close the session
            session.close()

@dictionary_bp.route('/result/<int:result_id>')
def view_result(result_id):
    """View details of a specific processing result."""
    # Get the result and related entries
    result = ProcessingResult.query.get_or_404(result_id)
    entries = DictionaryEntry.query.filter_by(processing_result_id=result.id).all()
    
    # Get the associated image and prompt
    image = result.image
    prompt = result.prompt
    
    return render_template(
        'dictionary/view_result.html',
        result=result,
        entries=entries,
        image=image,
        prompt=prompt
    )

@dictionary_bp.route('/entries')
def all_entries():
    """View all dictionary entries with filtering options"""
    
    # Query parameters for filtering
    search_term = request.args.get('search', '')
    project_id = request.args.get('project_id', type=int)
    page_id = request.args.get('page_id', type=int)
    sort_by = request.args.get('sort', 'estonian_headword')
    sort_order = request.args.get('order', 'asc')
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    
    # Base query for dictionary entries
    query = DictionaryEntry.query
    
    # Apply filters
    if search_term:
        search_term = f"%{search_term}%"
        query = query.filter(
            db.or_(
                DictionaryEntry.estonian_headword.ilike(search_term),
                DictionaryEntry.german_equivalent.ilike(search_term),
                DictionaryEntry.latin_explanation.ilike(search_term),
                DictionaryEntry.estonian_synonyms.ilike(search_term),
                DictionaryEntry.german_synonyms.ilike(search_term),
                DictionaryEntry.part_of_speech.ilike(search_term)
            )
        )
    
    if project_id:
        query = query.filter_by(project_id=project_id)
    
    if page_id:
        query = query.filter_by(page_id=page_id)
    
    # Apply sorting
    if sort_order == 'desc':
        query = query.order_by(db.desc(getattr(DictionaryEntry, sort_by)))
    else:
        query = query.order_by(getattr(DictionaryEntry, sort_by))
    
    # Paginate results
    entries_pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    entries = entries_pagination.items
    
    # Get all projects for the filter dropdown
    projects = Project.query.order_by(Project.name).all()
    
    # Get pages for the selected project
    pages = []
    if project_id:
        pages = Page.query.filter_by(project_id=project_id).order_by(Page.page_number).all()
    
    return render_template(
        'dictionary/entries.html',
        entries=entries,
        pagination=entries_pagination,
        search_term=search_term,
        project_id=project_id,
        page_id=page_id,
        sort_by=sort_by,
        sort_order=sort_order,
        projects=projects,
        pages=pages,
        per_page=per_page
    )

@dictionary_bp.route('/export/<int:result_id>/<format>')
def export_result(result_id, format):
    """Export a processing result in various formats"""
    result = ProcessingResult.query.get_or_404(result_id)
    entries = result.dictionary_entries
    
    if format == 'json':
        # Export as JSON
        entries_data = [entry.to_dict() for entry in entries]
        
        # Return as a downloadable file
        return jsonify(entries_data)
        
    elif format == 'csv':
        # Export as CSV
        output = StringIO()
        writer = csv.writer(output)
        
        # Write header
        writer.writerow([
            'estonian_headword', 
            'estonian_synonyms', 
            'german_equivalent', 
            'german_synonyms',
            'latin_explanation', 
            'part_of_speech', 
            'estonian_declension', 
            'estonian_mwu', 
            'translated_mwu'
        ])
        
        # Write entries
        for entry in entries:
            writer.writerow([
                entry.estonian_headword,
                entry.estonian_synonyms,
                entry.german_equivalent,
                entry.german_synonyms,
                entry.latin_explanation,
                entry.part_of_speech,
                entry.estonian_declension,
                entry.estonian_mwu,
                entry.translated_mwu
            ])
        
        # Create response
        output.seek(0)
        return output.getvalue(), 200, {
            'Content-Type': 'text/csv',
            'Content-Disposition': f'attachment; filename=result_{result_id}.csv'
        }
        
    elif format == 'markdown':
        # Export as Markdown
        markdown = "# Dictionary Entries\n\n"
        
        for entry in entries:
            markdown += f"## {entry.estonian_headword}\n\n"
            
            if entry.part_of_speech:
                markdown += f"*{entry.part_of_speech}*\n\n"
                
            if entry.estonian_declension:
                markdown += f"**Declension:** {entry.estonian_declension}\n\n"
                
            if entry.estonian_synonyms:
                markdown += f"**Estonian Synonyms:** {entry.estonian_synonyms}\n\n"
                
            markdown += f"**German:** {entry.german_equivalent}\n\n"
            
            if entry.german_synonyms:
                markdown += f"**German Synonyms:** {entry.german_synonyms}\n\n"
                
            if entry.latin_explanation:
                markdown += f"**Latin:** {entry.latin_explanation}\n\n"
                
            if entry.estonian_mwu:
                markdown += f"**Examples:** {entry.estonian_mwu}\n\n"
                
            if entry.translated_mwu:
                markdown += f"**Translated Examples:** {entry.translated_mwu}\n\n"
                
            markdown += "---\n\n"
        
        # Create response
        return markdown, 200, {
            'Content-Type': 'text/markdown',
            'Content-Disposition': f'attachment; filename=result_{result_id}.md'
        }
    
    # Invalid format
    flash('Invalid export format.', 'danger')
    return redirect(url_for('dictionary.view_result', result_id=result_id))

@dictionary_bp.route('/evaluate-entry', methods=['POST'])
def evaluate_entry():
    """
    API endpoint to mark an entry as correct, incorrect, or neutral (clear evaluation)
    """
    try:
        data = request.get_json()
        entry_id = data.get('entry_id')
        action = data.get('action')
        
        if not entry_id:
            return jsonify({'success': False, 'error': 'Entry ID is required'}), 400
            
        entry = DictionaryEntry.query.get(entry_id)
        if not entry:
            return jsonify({'success': False, 'error': f'Entry with ID {entry_id} not found'}), 404
        
        if action == 'neutral':
            # Clear the evaluation
            entry.is_evaluated = False
            entry.is_correct = None
        else:
            # Set as correct or incorrect
            entry.is_evaluated = True
            entry.is_correct = (action == 'correct')
            
        entry.evaluated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'entry_id': entry_id,
            'action': action,
            'is_evaluated': entry.is_evaluated,
            'is_correct': entry.is_correct
        })
    except Exception as e:
        current_app.logger.error(f"Error evaluating entry: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@dictionary_bp.route('/results/<int:result_id>/raw')
def view_raw_result(result_id):
    """View raw JSON response from API"""
    result = ProcessingResult.query.get_or_404(result_id)
    return render_template('dictionary/raw_response.html', result=result)

@dictionary_bp.route('/results/<int:result_id>/delete', methods=['POST'])
def delete_result(result_id):
    """Delete a processing result and its dictionary entries"""
    result = ProcessingResult.query.get_or_404(result_id)
    
    # Get task associated with this result if any
    task = result.task
    
    # Delete dictionary entries first (should be handled by cascade but being explicit)
    for entry in result.dictionary_entries:
        db.session.delete(entry)
    
    # Delete the processing result
    db.session.delete(result)
    db.session.commit()
    
    flash('Processing result and its dictionary entries deleted successfully', 'success')
    
    # If this was tied to a task, return to the task view
    if task:
        return redirect(url_for('tasks.view', task_id=task.id))
    else:
        return redirect(url_for('dictionary.index'))

@dictionary_bp.route('/entries/<int:entry_id>/delete', methods=['POST'])
def delete_entry(entry_id):
    """Delete a dictionary entry"""
    entry = DictionaryEntry.query.get_or_404(entry_id)
    
    # Store the result_id before deleting the entry
    result_id = entry.processing_result_id
    
    # Delete the entry
    db.session.delete(entry)
    db.session.commit()
    
    # Update the num_entries count on the processing result
    result = ProcessingResult.query.get(result_id)
    if result:
        result.num_entries = len(result.dictionary_entries)
        db.session.commit()
    
    flash('Dictionary entry deleted successfully', 'success')
    
    # Redirect to the processing result view
    return redirect(url_for('dictionary.view_result', result_id=result_id))

@dictionary_bp.route('/entries/bulk-delete', methods=['POST'])
def bulk_delete_entries():
    """Delete multiple dictionary entries at once."""
    entry_ids_string = request.form.get('entry_ids', '')
    return_url = request.form.get('return_url', url_for('dictionary.index'))
    
    if not entry_ids_string:
        flash('No entries selected for deletion.', 'warning')
        return redirect(return_url)
    
    entry_ids = [int(id) for id in entry_ids_string.split(',') if id.strip()]
    entries = DictionaryEntry.query.filter(DictionaryEntry.id.in_(entry_ids)).all()
    
    if not entries:
        flash('No valid entries found for deletion.', 'warning')
        return redirect(return_url)
    
    # Group entries by processing_result_id to update counts later
    result_ids = set()
    for entry in entries:
        result_ids.add(entry.processing_result_id)
        db.session.delete(entry)
    
    db.session.commit()
    
    # Update num_entries count for each affected processing result
    for result_id in result_ids:
        result = ProcessingResult.query.get(result_id)
        if result:
            result.num_entries = len(result.dictionary_entries)
    
    db.session.commit()
    
    flash(f'Successfully deleted {len(entries)} dictionary entries.', 'success')
    return redirect(return_url)

@dictionary_bp.route('/get_task_stats')
def get_task_stats():
    """Get statistics for one or more tasks."""
    task_ids_str = request.args.get('task_ids')
    task_id = request.args.get('task_id', type=int)  # Keep single task_id support for backward compatibility
    
    if not task_ids_str and not task_id:
        return jsonify({'success': False, 'error': 'No task IDs provided'}), 400
        
    # Convert task_ids string to list of integers
    task_ids = []
    if task_ids_str:
        task_ids = [int(id) for id in task_ids_str.split(',') if id.strip()]
    if task_id:
        task_ids.append(task_id)
        
    # Get tasks and their stats
    tasks = {}
    for task_id in task_ids:
        task = Task.query.get(task_id)
        if not task:
            continue
            
        # Get processing result and entries if they exist
        result = ProcessingResult.query.filter_by(task_id=task_id).first()
        stats = {
            'status': task.status,
            'progress': task.progress,
            'total_entries': 0,
            'evaluated_entries': 0,
            'correct_entries': 0,
            'accuracy': 0
        }
        
        if result:
            entries = DictionaryEntry.query.filter_by(processing_result_id=result.id).all()
            stats.update({
                'total_entries': len(entries),
                'evaluated_entries': sum(1 for e in entries if e.is_evaluated),
                'correct_entries': sum(1 for e in entries if e.is_evaluated and e.is_correct)
            })
            if stats['evaluated_entries'] > 0:
                stats['accuracy'] = (stats['correct_entries'] / stats['evaluated_entries'] * 100)
                
        tasks[str(task_id)] = stats
    
    # If only one task was requested, maintain backward compatibility
    if task_id and not task_ids_str:
        if str(task_id) in tasks:
            return jsonify({'success': True, **tasks[str(task_id)]})
        return jsonify({'success': False, 'error': 'No task found'}), 404
        
    return jsonify({'success': True, 'tasks': tasks})

@dictionary_bp.route('/entries/add', methods=['POST'])
def add_entry():
    """Add a new dictionary entry"""
    try:
        # Get form data
        data = {
            'estonian_headword': request.form.get('estonian_headword'),
            'german_equivalent': request.form.get('german_equivalent'),
            'part_of_speech': request.form.get('part_of_speech'),
            'latin_explanation': request.form.get('latin_explanation'),
            'estonian_synonyms': request.form.get('estonian_synonyms'),
            'german_synonyms': request.form.get('german_synonyms'),
            'estonian_mwu': request.form.get('estonian_mwu'),
            'translated_mwu': request.form.get('translated_mwu'),
            'page_id': request.form.get('page_id', type=int)
        }
        
        # Validate required fields
        if not data['estonian_headword'] or not data['german_equivalent']:
            return jsonify({'success': False, 'error': 'Estonian headword and German equivalent are required'}), 400
            
        # Get the page to set project_id
        page = Page.query.get(data['page_id'])
        if not page:
            return jsonify({'success': False, 'error': 'Invalid page ID'}), 400
            
        # Find processing_result_id from the page's selected task
        processing_result_id = None
        if page.selected_task_id:
            result = ProcessingResult.query.filter_by(task_id=page.selected_task_id).first()
            if result:
                processing_result_id = result.id
        
        # If no processing result found from selected task, find from most recent task
        if not processing_result_id:
            latest_task = Task.query.filter_by(page_id=page.id).order_by(Task.start_time.desc()).first()
            if latest_task:
                result = ProcessingResult.query.filter_by(task_id=latest_task.id).first()
                if result:
                    processing_result_id = result.id
        
        # Create new entry
        entry = DictionaryEntry(
            processing_result_id=processing_result_id,
            estonian_headword=data['estonian_headword'],
            german_equivalent=data['german_equivalent'],
            part_of_speech=data['part_of_speech'],
            latin_explanation=data['latin_explanation'],
            estonian_synonyms=data['estonian_synonyms'],
            german_synonyms=data['german_synonyms'],
            estonian_mwu=data['estonian_mwu'],
            translated_mwu=data['translated_mwu'],
            page_id=data['page_id'],
            project_id=page.project_id,
            order=DictionaryEntry.query.filter_by(page_id=data['page_id']).count(),  # Add at the end
            # Set modification fields
            is_user_added=True,
            last_modified_at=datetime.utcnow()
        )
        
        db.session.add(entry)
        db.session.commit()
        
        return jsonify({'success': True, 'entry_id': entry.id})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': f'Error adding entry: {str(e)}'}), 500

@dictionary_bp.route('/entries/<int:entry_id>', methods=['GET'])
def get_entry(entry_id):
    """Get a dictionary entry by ID"""
    try:
        entry = DictionaryEntry.query.get(entry_id)
        if not entry:
            return jsonify({'success': False, 'error': 'Entry not found'}), 404
            
        entry_data = {
            'estonian_headword': entry.estonian_headword,
            'german_equivalent': entry.german_equivalent,
            'part_of_speech': entry.part_of_speech,
            'latin_explanation': entry.latin_explanation,
            'estonian_synonyms': entry.estonian_synonyms,
            'german_synonyms': entry.german_synonyms,
            'estonian_mwu': entry.estonian_mwu,
            'translated_mwu': entry.translated_mwu
        }
        
        return jsonify({'success': True, 'entry': entry_data})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@dictionary_bp.route('/entries/<int:entry_id>/update', methods=['POST'])
def update_entry(entry_id):
    """Update a dictionary entry"""
    try:
        entry = DictionaryEntry.query.get(entry_id)
        if not entry:
            return jsonify({'success': False, 'error': 'Entry not found'}), 404
            
        # Update fields
        entry.estonian_headword = request.form.get('estonian_headword', entry.estonian_headword)
        entry.german_equivalent = request.form.get('german_equivalent', entry.german_equivalent)
        entry.part_of_speech = request.form.get('part_of_speech', entry.part_of_speech)
        entry.latin_explanation = request.form.get('latin_explanation', entry.latin_explanation)
        entry.estonian_synonyms = request.form.get('estonian_synonyms', entry.estonian_synonyms)
        entry.german_synonyms = request.form.get('german_synonyms', entry.german_synonyms)
        entry.estonian_mwu = request.form.get('estonian_mwu', entry.estonian_mwu)
        entry.translated_mwu = request.form.get('translated_mwu', entry.translated_mwu)
        
        # Set modification fields
        entry.is_user_modified = True
        entry.last_modified_at = datetime.utcnow()
        
        # Validate required fields
        if not entry.estonian_headword or not entry.german_equivalent:
            return jsonify({'success': False, 'error': 'Estonian headword and German equivalent are required'}), 400
            
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@dictionary_bp.route('/entries/reorder', methods=['POST'])
def reorder_entries():
    """Update the order of dictionary entries"""
    try:
        entries_data = request.json.get('entries', [])
        if not entries_data:
            return jsonify({'success': False, 'error': 'No entries provided'}), 400
            
        # Update each entry's order
        for entry_data in entries_data:
            entry_id = entry_data.get('id')
            new_order = entry_data.get('order')
            
            if entry_id is None or new_order is None:
                continue
                
            entry = DictionaryEntry.query.get(entry_id)
            if entry:
                entry.order = new_order
        
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500 