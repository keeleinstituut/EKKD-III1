from flask import Blueprint, render_template
from app.models.models import Prompt, Project

drafts_bp = Blueprint('drafts', __name__)

@drafts_bp.route('/prompts')
def prompts():
    # Get unassigned prompts (where project_id is None)
    prompts = Prompt.query.filter_by(project_id=None).order_by(Prompt.updated_date.desc()).all()
    # Get all projects for the assignment dropdown, sorted by name
    projects = Project.query.order_by(Project.name).all()
    return render_template('drafts/prompts.html', prompts=prompts, projects=projects)

# Add any additional draft-related routes here 