from flask import Blueprint, render_template, jsonify, request, flash, redirect, url_for, abort, current_app, session
from app.models.models import Task, Image, Prompt, ProcessingResult, Project, Page, TaskStatus
from app import db
import datetime
import json
import threading
from app.routes.dictionary import process_image_thread

tasks_bp = Blueprint('tasks', __name__, url_prefix='/tasks')

@tasks_bp.route('/')
def index():
    """List all tasks, grouped by status"""
    # Get active tasks (running and queued)
    active_tasks = Task.query.filter(Task.status.in_(['running', 'queued'])).order_by(Task.start_time.desc()).all()
    
    # Get completed tasks
    completed_tasks = Task.query.filter_by(status='completed').order_by(Task.end_time.desc()).limit(20).all()
    
    # Get failed tasks
    failed_tasks = Task.query.filter_by(status='failed').order_by(Task.end_time.desc()).limit(20).all()
    
    # Get projects for filtering
    projects = Project.query.order_by(Project.name).all()
    
    # Apply project filter if specified
    project_id = request.args.get('project_id', type=int)
    selected_project = None
    
    if project_id:
        selected_project = Project.query.get(project_id)
        if selected_project:
            active_tasks = [t for t in active_tasks if t.project_id == project_id]
            completed_tasks = [t for t in completed_tasks if t.project_id == project_id]
            failed_tasks = [t for t in failed_tasks if t.project_id == project_id]
    
    return render_template('tasks/index.html', 
                         active_tasks=active_tasks,
                         completed_tasks=completed_tasks,
                         failed_tasks=failed_tasks,
                         projects=projects,
                         selected_project=selected_project)

@tasks_bp.route('/create', methods=['GET', 'POST'])
def create():
    """Create a new task"""
    if request.method == 'POST':
        project_id = request.form.get('project_id', type=int)
        page_id = request.form.get('page_id', type=int)
        prompt_id = request.form.get('prompt_id', type=int)
        set_as_selected_val = request.form.get('set_as_selected')
        set_as_selected = set_as_selected_val == 'on' or set_as_selected_val == 'true'
        
        # Get API key from session
        api_key = session.get('api_key')
        if not api_key:
            if request.headers.get('Accept') == 'application/json':
                return jsonify({
                    'success': False,
                    'message': 'No API key configured. Please configure your API key first.'
                })
            flash('No API key configured. Please configure your API key first.', 'error')
            return redirect(url_for('main.api_key'))
        
        # Validate required fields
        if not all([project_id, page_id, prompt_id]):
            if request.headers.get('Accept') == 'application/json':
                return jsonify({
                    'success': False,
                    'message': 'Missing required fields'
                })
            flash('Missing required fields', 'error')
            return redirect(url_for('tasks.create'))
        
        # Get the page and its first image
        page = Page.query.get_or_404(page_id)
        if not page.images:
            if request.headers.get('Accept') == 'application/json':
                return jsonify({
                    'success': False,
                    'message': 'Selected page has no images'
                })
            flash('Selected page has no images', 'error')
            return redirect(url_for('tasks.create'))
            
        # Get the prompt
        prompt = Prompt.query.get_or_404(prompt_id)
        
        # Create task metadata
        task_metadata = {
            'page_number': page.page_number,
            'model': prompt.model,
            'max_tokens': prompt.max_tokens,
            'enable_thinking': prompt.enable_thinking,
            'set_as_selected': set_as_selected
        }
        
        # Create new task
        task = Task(
            task_type='dictionary_processing',
            status='queued',
            work_status=TaskStatus.DRAFT.value,
            project_id=project_id,
            page_id=page_id,
            image_id=page.images[0].id,  # Use the first image of the page
            prompt_id=prompt_id,
            task_metadata=json.dumps(task_metadata)
        )
        
        db.session.add(task)
        db.session.commit()
        
        # Start processing in a background thread
        thread = threading.Thread(
            target=process_image_thread,
            args=(current_app._get_current_object(), page.images[0], prompt, page.page_number, api_key, task.id)
        )
        thread.daemon = True
        thread.start()
        
        if request.headers.get('Accept') == 'application/json':
            return jsonify({
                'success': True,
                'redirect_url': url_for('tasks.view', task_id=task.id)
            })
            
        flash(f'Task created successfully', 'success')
        return redirect(url_for('tasks.view', task_id=task.id))
    
    # Handle GET request - show form
    project_id = request.args.get('project_id', type=int)
    page_id = request.args.get('page_id', type=int)
    
    project = None
    pages = []
    if project_id:
        project = Project.query.get_or_404(project_id)
        pages = Page.query.filter_by(project_id=project_id).order_by(Page.page_number).all()
    
    prompts = Prompt.query.order_by(Prompt.name).all()
    
    return render_template('tasks/create.html',
                          project=project,
                          pages=pages,
                          prompts=prompts,
                          selected_project_id=project_id)

@tasks_bp.route('/<int:task_id>')
def view(task_id):
    """View a specific task details and logs"""
    task = Task.query.get_or_404(task_id)
    
    # Parse logs for display
    try:
        logs = []
        log_entries = json.loads(task.log or '[]')
        for entry in log_entries:
            # Convert timestamp string to datetime
            try:
                timestamp = datetime.datetime.fromisoformat(entry.get('timestamp'))
            except ValueError:
                timestamp = datetime.datetime.utcnow()
                
            logs.append({
                'timestamp': timestamp,
                'level': entry.get('status', 'INFO').upper(),
                'message': entry.get('message', ''),
                'progress': entry.get('progress', 0)
            })
    except Exception as e:
        logs = [{
            'timestamp': datetime.datetime.utcnow(),
            'level': 'ERROR',
            'message': f'Error parsing log entries: {str(e)}',
            'progress': 0
        }]
    
    return render_template('tasks/view.html', task=task, logs=logs)

@tasks_bp.route('/logs/<int:task_id>')
def logs(task_id):
    """Get the logs for a specific task (for AJAX refresh)"""
    task = Task.query.get_or_404(task_id)
    
    # Parse logs for display
    try:
        logs = []
        log_entries = json.loads(task.log or '[]')
        for entry in log_entries:
            # Convert timestamp string to datetime
            try:
                timestamp = datetime.datetime.fromisoformat(entry.get('timestamp'))
            except ValueError:
                timestamp = datetime.datetime.utcnow()
                
            logs.append({
                'timestamp': timestamp,
                'level': entry.get('status', 'INFO').upper(),
                'message': entry.get('message', ''),
                'progress': entry.get('progress', 0)
            })
    except Exception as e:
        logs = [{
            'timestamp': datetime.datetime.utcnow(),
            'level': 'ERROR',
            'message': f'Error parsing log entries: {str(e)}',
            'progress': 0
        }]
    
    # Return formatted HTML
    return render_template('tasks/logs_partial.html', logs=logs)

@tasks_bp.route('/<int:task_id>/cancel', methods=['POST'])
def cancel(task_id):
    """Cancel a running or queued task"""
    task = Task.query.get_or_404(task_id)
    
    if task.status not in ['queued', 'running']:
        flash('Only queued or running tasks can be cancelled.', 'warning')
        return redirect(url_for('tasks.view', task_id=task_id))
    
    # Update the task status
    task.update_status(
        'failed',
        log_entry='Task cancelled by user',
        error='Task was manually cancelled',
        progress=task.progress
    )
    
    flash('Task has been successfully cancelled.', 'success')
    return redirect(url_for('tasks.view', task_id=task_id))

@tasks_bp.route('/<int:task_id>/work-status', methods=['POST'])
def update_work_status(task_id):
    """Update the work status of a task"""
    task = Task.query.get_or_404(task_id)
    
    work_status = request.form.get('work_status')
    if not work_status or work_status not in [status.value for status in TaskStatus]:
        flash('Invalid work status', 'error')
        return redirect(url_for('tasks.view', task_id=task_id))
    
    task.update_work_status(work_status)
    
    flash('Task work status updated successfully', 'success')
    
    # Redirect back to the referring page if available
    next_page = request.form.get('next') or request.referrer
    if next_page:
        return redirect(next_page)
    return redirect(url_for('tasks.view', task_id=task_id))

@tasks_bp.route('/assign/<int:id>', methods=['GET', 'POST'])
def assign(id):
    """Assign a task to a project/page"""
    task = Task.query.get_or_404(id)
    projects = Project.query.order_by(Project.name).all()
    
    if request.method == 'POST':
        project_id = request.form.get('project_id', type=int)
        page_id = request.form.get('page_id', type=int)
        
        if not project_id:
            flash('Please select a project.', 'danger')
            return redirect(url_for('tasks.assign', id=id))
        
        project = Project.query.get(project_id)
        if not project:
            flash('Selected project not found.', 'danger')
            return redirect(url_for('tasks.assign', id=id))
        
        # Update task with project and page if provided
        task.project_id = project_id
        
        if page_id:
            page = Page.query.get(page_id)
            if page and page.project_id == project_id:
                task.page_id = page_id
        
        db.session.commit()
        flash(f'Task successfully assigned to project "{project.name}".', 'success')
        return redirect(url_for('tasks.view', id=id))
    
    # Get pages for the initial project (if task already has a project)
    initial_pages = []
    if task.project_id:
        initial_pages = Page.query.filter_by(project_id=task.project_id).order_by(Page.page_number).all()
    
    return render_template('tasks/assign.html', 
                          task=task, 
                          projects=projects,
                          initial_pages=initial_pages)

@tasks_bp.route('/batch_assign', methods=['POST'])
def batch_assign():
    """Batch assign multiple tasks to a project/page"""
    # Get task ids from form
    task_ids_str = request.form.get('task_ids', '')
    project_id = request.form.get('project_id', type=int)
    page_id = request.form.get('page_id', type=int)
    
    if not task_ids_str or not project_id:
        flash('Missing required parameters.', 'danger')
        return redirect(url_for('main.drafts', content_type='tasks'))
    
    # Validate project
    project = Project.query.get(project_id)
    if not project:
        flash('Selected project not found.', 'danger')
        return redirect(url_for('main.drafts', content_type='tasks'))
    
    # Parse task IDs
    try:
        task_ids = [int(id) for id in task_ids_str.split(',')]
    except ValueError:
        flash('Invalid task IDs provided.', 'danger')
        return redirect(url_for('main.drafts', content_type='tasks'))
    
    # Validate page if provided
    page = None
    if page_id:
        page = Page.query.get(page_id)
        if not page or page.project_id != project_id:
            flash('Selected page is not valid for the chosen project.', 'danger')
            return redirect(url_for('main.drafts', content_type='tasks'))
    
    # Update tasks
    assigned_count = 0
    for task_id in task_ids:
        task = Task.query.get(task_id)
        if task:
            task.project_id = project_id
            if page_id:
                task.page_id = page_id
            assigned_count += 1
    
    if assigned_count > 0:
        db.session.commit()
        flash(f'Successfully assigned {assigned_count} tasks to project "{project.name}".', 'success')
    else:
        flash('No tasks were assigned. The selected tasks may no longer exist.', 'warning')
    
    return redirect(url_for('main.drafts', content_type='tasks'))

@tasks_bp.route('/api/active')
def api_active_tasks():
    """API endpoint to get active tasks for the dashboard"""
    active_tasks = Task.query.filter(Task.status.in_(['running', 'queued'])).all()
    return jsonify({
        'success': True,
        'tasks': [task.to_dict() for task in active_tasks]
    })

@tasks_bp.route('/bulk-delete', methods=['POST'])
def bulk_delete():
    """Delete multiple tasks at once."""
    task_ids_string = request.form.get('task_ids', '')
    return_url = request.form.get('return_url', url_for('tasks.index'))
    
    if not task_ids_string:
        flash('No tasks selected for deletion.', 'warning')
        return redirect(return_url)
    
    task_ids = [int(id) for id in task_ids_string.split(',') if id.strip()]
    tasks = Task.query.filter(Task.id.in_(task_ids)).all()
    
    deleted_count = 0
    for task in tasks:
        # Only delete completed or failed tasks
        if task.status in ['completed', 'failed']:
            # Delete associated processing result and its dictionary entries
            if task.processing_result:
                # Delete dictionary entries associated with this result
                for entry in task.processing_result.dictionary_entries:
                    db.session.delete(entry)
                db.session.delete(task.processing_result)
            
            # Delete the task
            db.session.delete(task)
            deleted_count += 1
    
    db.session.commit()
    
    if deleted_count > 0:
        flash(f'Successfully deleted {deleted_count} tasks and their associated results.', 'success')
    else:
        flash('No eligible tasks were deleted. Only completed or failed tasks can be deleted.', 'warning')
    
    return redirect(return_url)

@tasks_bp.route('/delete/<int:id>')
def delete(id):
    """Delete a task."""
    task = Task.query.get_or_404(id)
    
    # Only allow deletion of completed or failed tasks
    if task.status not in ['completed', 'failed']:
        flash('Only completed or failed tasks can be deleted.', 'danger')
        return redirect(url_for('tasks.view', task_id=id))
    
    # If task has a project, redirect back to the project after deletion
    project_id = task.project_id
    page_id = task.page_id
    
    # Delete associated processing result and its dictionary entries
    if task.processing_result:
        # Delete dictionary entries associated with this result
        for entry in task.processing_result.dictionary_entries:
            db.session.delete(entry)
        db.session.delete(task.processing_result)
    
    # Delete the task
    db.session.delete(task)
    db.session.commit()
    
    flash('Task and all associated results successfully deleted.', 'success')
    
    # If we came from a page view, go back there
    if page_id and project_id:
        return redirect(url_for('projects.view_page', project_id=project_id, page_id=page_id))
    # If task has a project but no page, go to project
    elif project_id:
        return redirect(url_for('projects.view', id=project_id))
    else:
        return redirect(url_for('main.drafts', content_type='tasks'))

@tasks_bp.route('/<int:task_id>/retry', methods=['POST'])
def retry(task_id):
    """Retry a failed task with the same parameters"""
    task = Task.query.get_or_404(task_id)
    
    if task.status != 'failed':
        flash('Only failed tasks can be retried.', 'warning')
        return redirect(url_for('tasks.view', task_id=task_id))
    
    if not task.image or not task.prompt:
        flash('Cannot retry task: missing image or prompt.', 'danger')
        return redirect(url_for('tasks.view', task_id=task_id))
    
    # Get API key from session
    api_key = session.get('api_key')
    if not api_key:
        flash('API key not found in session. Please try processing again.', 'danger')
        return redirect(url_for('tasks.view', task_id=task_id))
    
    # Create new task with same properties
    metadata = task.get_metadata_dict()
    new_task = Task(
        task_type=task.task_type,
        status="queued",
        image_id=task.image_id,
        prompt_id=task.prompt_id,
        project_id=task.project_id,
        page_id=task.page_id,
        progress=0,
        task_metadata=json.dumps(metadata)
    )
    db.session.add(new_task)
    db.session.commit()
    
    # Start processing in a background thread
    thread = threading.Thread(
        target=process_image_thread,
        args=(current_app._get_current_object(), task.image, task.prompt, metadata.get('page_number', 1), api_key, new_task.id, task.project_id, task.page_id)
    )
    thread.daemon = True
    thread.start()
    
    flash(f'Task has been restarted with the same parameters.', 'success')
    return redirect(url_for('tasks.view', task_id=new_task.id)) 