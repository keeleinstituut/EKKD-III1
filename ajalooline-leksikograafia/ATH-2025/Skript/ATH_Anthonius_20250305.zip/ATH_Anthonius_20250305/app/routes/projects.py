from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify, abort, Response
from app import db
from app.models.models import Project, Page, Image, Task, TaskStatus, DictionaryEntry, ProcessingResult, Prompt
from datetime import datetime
import json
import csv
from io import StringIO
from werkzeug.utils import secure_filename
import os
from flask import current_app

projects_bp = Blueprint('projects', __name__, url_prefix='/projects')

@projects_bp.route('/')
def index():
    """List all projects"""
    # Get sort parameters from query string
    sort_by = request.args.get('sort', 'pages')  # Default sort by pages
    order = request.args.get('order', 'desc')    # Default order descending
    
    # Base query
    query = Project.query
    
    # Apply sorting
    if sort_by == 'name':
        query = query.order_by(Project.name.desc() if order == 'desc' else Project.name)
    elif sort_by == 'updated':
        query = query.order_by(Project.updated_date.desc() if order == 'desc' else Project.updated_date)
    elif sort_by == 'tasks':
        # We'll sort in Python since it's a relationship count
        projects = query.all()
        projects.sort(key=lambda p: len(p.tasks), reverse=(order == 'desc'))
    elif sort_by == 'entries':
        # We'll sort in Python since it's a complex count
        projects = query.all()
        projects.sort(key=lambda p: p.dictionary_entries.count(), reverse=(order == 'desc'))
    else:  # sort_by == 'pages' (default)
        # We'll sort in Python since it's a relationship count
        projects = query.all()
        projects.sort(key=lambda p: len(p.pages), reverse=(order == 'desc'))
    
    # If we haven't sorted in Python yet, get the results
    if sort_by not in ['tasks', 'entries', 'pages']:
        projects = query.all()
    
    # Get active tasks
    active_tasks = Task.query.filter(
        Task.status.in_(['queued', 'running'])
    ).order_by(Task.start_time.desc()).limit(5).all()
    
    # Get recent dictionary entries using the processing_result's timestamp
    recent_entries = DictionaryEntry.query.join(
        ProcessingResult
    ).order_by(
        ProcessingResult.timestamp.desc()
    ).limit(5).all()
    
    # Calculate total statistics
    total_stats = {
        'projects': len(projects),
        'pages': sum(len(p.pages) for p in projects),
        'tasks': sum(len(p.tasks) for p in projects),
        'entries': DictionaryEntry.query.count()
    }
    
    return render_template('projects/index.html', 
                         projects=projects,
                         active_tasks=active_tasks,
                         recent_entries=recent_entries,
                         total_stats=total_stats,
                         sort_by=sort_by,
                         order=order)

@projects_bp.route('/create', methods=['GET', 'POST'])
def create():
    """Create a new project"""
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        
        if not name:
            flash('Project name is required', 'error')
            return redirect(url_for('projects.create'))
        
        project = Project(
            name=name,
            description=description
        )
        
        db.session.add(project)
        db.session.commit()
        
        flash(f'Project "{name}" created successfully', 'success')
        return redirect(url_for('projects.view', id=project.id))
    
    return render_template('projects/create.html')

@projects_bp.route('/<int:id>')
def view(id):
    """View a project."""
    project = Project.query.get_or_404(id)
    
    # Get sort parameters from query string
    sort_by = request.args.get('sort', 'number')  # Default sort by page number
    order = request.args.get('order', 'asc')      # Default order ascending
    
    # Base query for pages
    query = Page.query.filter_by(project_id=id)
    
    # Apply sorting
    if sort_by == 'updated':
        query = query.order_by(Page.updated_date.desc() if order == 'desc' else Page.updated_date)
    elif sort_by == 'entries':
        # We'll sort by entries count in Python since it requires joining through multiple tables
        pages = query.all()
        pages.sort(
            key=lambda p: len(DictionaryEntry.query.join(ProcessingResult)
                            .filter(ProcessingResult.task_id == p.selected_task_id).all()) if p.selected_task_id else 0,
            reverse=(order == 'desc')
        )
    else:  # sort_by == 'number' (default)
        query = query.order_by(Page.page_number.desc() if order == 'desc' else Page.page_number)
    
    # Get pages if we haven't already
    if sort_by != 'entries':
        pages = query.all()
    
    # Get dictionary entries from selected tasks through processing results
    project_dictionary = []
    for page in pages:
        if page.selected_task_id:
            # Get the processing result for the selected task
            processing_result = ProcessingResult.query.filter_by(task_id=page.selected_task_id).first()
            if processing_result:
                entries = DictionaryEntry.query.filter_by(processing_result_id=processing_result.id).all()
                project_dictionary.extend(entries)
    
    # Calculate dictionary statistics
    total_entries = len(project_dictionary)
    evaluated_entries = sum(1 for e in project_dictionary if e.is_evaluated)
    correct_entries = sum(1 for e in project_dictionary if e.is_evaluated and e.is_correct)
    incorrect_entries = sum(1 for e in project_dictionary if e.is_evaluated and not e.is_correct)
    accuracy = (correct_entries / evaluated_entries * 100) if evaluated_entries > 0 else 0
    
    project_dictionary_stats = {
        'total_entries': total_entries,
        'evaluated_entries': evaluated_entries,
        'correct_entries': correct_entries,
        'incorrect_entries': incorrect_entries,
        'accuracy': round(accuracy, 1)
    }
    
    # Get page dictionary counts for the card badges
    page_dictionary_counts = {}
    for page in pages:
        if page.selected_task_id:
            # Get the processing result for the selected task
            processing_result = ProcessingResult.query.filter_by(task_id=page.selected_task_id).first()
            if processing_result:
                count = DictionaryEntry.query.filter_by(processing_result_id=processing_result.id).count()
                page_dictionary_counts[page.id] = count
    
    # Get progress stats
    progress_stats = {
        'total': len(pages),
        'complete': sum(1 for p in pages if p.selected_task_id)
    }
    
    return render_template(
        'projects/view.html',
        project=project,
        pages=pages,
        progress_stats=progress_stats,
        page_dictionary_counts=page_dictionary_counts,
        project_dictionary=project_dictionary,
        project_dictionary_stats=project_dictionary_stats,
        sort_by=sort_by,
        order=order
    )

@projects_bp.route('/<int:id>/edit', methods=['GET', 'POST'])
def edit(id):
    """Edit a project"""
    project = Project.query.get_or_404(id)
    
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        
        if not name:
            flash('Project name is required', 'error')
            return redirect(url_for('projects.edit', id=id))
        
        project.name = name
        project.description = description
        project.updated_date = datetime.utcnow()
        
        db.session.commit()
        
        flash(f'Project "{name}" updated successfully', 'success')
        return redirect(url_for('projects.view', id=id))
    
    return render_template('projects/edit.html', project=project)

@projects_bp.route('/<int:id>/delete', methods=['POST'])
def delete(id):
    """Delete a project"""
    project = Project.query.get_or_404(id)
    
    name = project.name
    db.session.delete(project)
    db.session.commit()
    
    flash(f'Project "{name}" deleted successfully', 'success')
    return redirect(url_for('projects.index'))

@projects_bp.route('/bulk-delete', methods=['POST'])
def bulk_delete():
    """Delete multiple projects at once."""
    project_ids_string = request.form.get('project_ids', '')
    
    if not project_ids_string:
        flash('No projects selected for deletion.', 'warning')
        return redirect(url_for('projects.index'))
    
    project_ids = [int(id) for id in project_ids_string.split(',') if id.strip()]
    projects = Project.query.filter(Project.id.in_(project_ids)).all()
    
    if not projects:
        flash('No valid projects found for deletion.', 'warning')
        return redirect(url_for('projects.index'))
    
    # Count for success message
    deleted_count = len(projects)
    project_names = [project.name for project in projects]
    
    # Delete each project
    for project in projects:
        db.session.delete(project)
    
    db.session.commit()
    
    if deleted_count == 1:
        flash(f'Project "{project_names[0]}" deleted successfully.', 'success')
    else:
        flash(f'{deleted_count} projects deleted successfully.', 'success')
    
    return redirect(url_for('projects.index'))

# Page management routes
@projects_bp.route('/<int:project_id>/pages')
def list_pages(project_id):
    """List all pages for a project"""
    project = Project.query.get_or_404(project_id)
    pages = Page.query.filter_by(project_id=project_id).order_by(Page.page_number).all()
    
    return render_template('projects/pages/index.html', 
                          project=project, 
                          pages=pages)

@projects_bp.route('/<int:project_id>/pages/create', methods=['GET', 'POST'])
def create_page(project_id):
    """Create a new page"""
    project = Project.query.get_or_404(project_id)
    
    if request.method == 'POST':
        page_number = request.form.get('page_number', type=int)
        notes = request.form.get('notes')
        
        if not page_number:
            flash('Page number is required', 'error')
            return redirect(url_for('projects.create_page', project_id=project_id))
        
        # Check if page with this number already exists
        existing_page = Page.query.filter_by(
            project_id=project_id, 
            page_number=page_number
        ).first()
        
        if existing_page:
            flash(f'Page {page_number} already exists for this project', 'error')
            return redirect(url_for('projects.create_page', project_id=project_id))
        
        page = Page(
            project_id=project_id,
            page_number=page_number,
            notes=notes
        )
        
        db.session.add(page)
        db.session.commit()
        
        flash(f'Page {page_number} created successfully', 'success')
        return redirect(url_for('projects.view_page', project_id=project_id, page_id=page.id))
    
    return render_template('projects/pages/create.html', project=project)

@projects_bp.route('/<int:project_id>/pages/<int:page_id>')
def view_page(project_id, page_id):
    """View a page"""
    project = Project.query.get_or_404(project_id)
    page = Page.query.get_or_404(page_id)
    
    if page.project_id != project_id:
        abort(404)
    
    images = Image.query.filter_by(page_id=page_id).all()
    tasks = Task.query.filter_by(page_id=page_id).order_by(Task.start_time.desc()).all()
    
    # Get count of dictionary entries for the page
    dictionary_count = DictionaryEntry.query.filter_by(page_id=page_id).count()
    
    return render_template('projects/pages/view.html', 
                          project=project, 
                          page=page, 
                          images=images, 
                          tasks=tasks,
                          dictionary_count=dictionary_count)

@projects_bp.route('/<int:project_id>/pages/<int:page_id>/edit', methods=['GET', 'POST'])
def edit_page(project_id, page_id):
    """Edit a page"""
    project = Project.query.get_or_404(project_id)
    page = Page.query.get_or_404(page_id)
    
    if page.project_id != project_id:
        abort(404)
    
    if request.method == 'POST':
        page_number = request.form.get('page_number', type=int)
        notes = request.form.get('notes')
        
        if not page_number:
            flash('Page number is required', 'error')
            return redirect(url_for('projects.edit_page', project_id=project_id, page_id=page_id))
        
        # Check if another page has this number
        existing_page = Page.query.filter(
            Page.project_id == project_id,
            Page.page_number == page_number,
            Page.id != page_id
        ).first()
        
        if existing_page:
            flash(f'Page {page_number} already exists for this project', 'error')
            return redirect(url_for('projects.edit_page', project_id=project_id, page_id=page_id))
        
        page.page_number = page_number
        page.notes = notes
        page.updated_date = datetime.utcnow()
        
        db.session.commit()
        
        flash(f'Page {page_number} updated successfully', 'success')
        return redirect(url_for('projects.view_page', project_id=project_id, page_id=page_id))
    
    return render_template('projects/pages/edit.html', project=project, page=page)

@projects_bp.route('/<int:project_id>/pages/<int:page_id>/delete', methods=['POST'])
def delete_page(project_id, page_id):
    """Delete a page"""
    project = Project.query.get_or_404(project_id)
    page = Page.query.get_or_404(page_id)
    
    if page.project_id != project_id:
        abort(404)
    
    page_number = page.page_number
    
    try:
        # Store references to page's tasks and images before breaking relationships
        page_tasks = list(page.tasks)
        page_images = list(page.images)
        
        # First, break circular references by nullifying foreign keys
        for image in page_images:
            # Break task -> image references
            for task in image.tasks:
                task.image_id = None
            # Break image -> page reference
            image.page_id = None
        
        # Break task -> page references
        for task in page_tasks:
            task.page_id = None
        
        # Commit these changes to break the circular references
        db.session.commit()
        
        # Now we can safely delete everything
        # Delete tasks and their dependencies
        for task in page_tasks:
            if task.processing_result:
                # Delete dictionary entries
                DictionaryEntry.query.filter_by(processing_result_id=task.processing_result.id).delete()
                # Delete processing result
                db.session.delete(task.processing_result)
            db.session.delete(task)
        
        # Delete images and their files
        for image in page_images:
            # Delete the actual file
            try:
                if os.path.exists(image.file_path):
                    os.remove(image.file_path)
            except Exception as e:
                current_app.logger.error(f'Could not delete image file: {str(e)}')
            db.session.delete(image)
        
        # Finally delete the page
        db.session.delete(page)
        db.session.commit()
        
        flash(f'Page {page_number} deleted successfully', 'success')
        return redirect(url_for('projects.view', id=project_id))
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f'Error deleting page: {str(e)}')
        flash('An error occurred while deleting the page', 'error')
        return redirect(url_for('projects.view_page', project_id=project_id, page_id=page_id))

# Task management routes
@projects_bp.route('/<int:project_id>/tasks')
def list_tasks(project_id):
    """List all tasks for a project"""
    project = Project.query.get_or_404(project_id)
    
    # Filter by work status if specified
    work_status = request.args.get('work_status')
    if work_status and work_status in [status.value for status in TaskStatus]:
        tasks = Task.query.filter_by(
            project_id=project_id,
            work_status=work_status
        ).order_by(Task.start_time.desc()).all()
    else:
        tasks = Task.query.filter_by(
            project_id=project_id
        ).order_by(Task.start_time.desc()).all()
    
    return render_template('projects/tasks/index.html', 
                          project=project, 
                          tasks=tasks,
                          current_status=work_status)

@projects_bp.route('/<int:project_id>/tasks/<int:task_id>/update-status', methods=['POST'])
def update_task_status(project_id, task_id):
    """Update task work status"""
    project = Project.query.get_or_404(project_id)
    task = Task.query.get_or_404(task_id)
    
    if task.project_id != project_id:
        abort(404)
    
    work_status = request.form.get('work_status')
    if not work_status or work_status not in [status.value for status in TaskStatus]:
        flash('Invalid task status', 'error')
        return redirect(url_for('projects.list_tasks', project_id=project_id))
    
    task.update_work_status(work_status)
    
    flash(f'Task status updated successfully', 'success')
    
    # Redirect back to the referring page if available
    next_page = request.form.get('next') or request.referrer
    if next_page:
        return redirect(next_page)
    return redirect(url_for('projects.list_tasks', project_id=project_id))

# API endpoints for AJAX
@projects_bp.route('/api/<int:id>/stats')
def api_project_stats(id):
    """Get project statistics (for AJAX)"""
    project = Project.query.get_or_404(id)
    stats = project.get_progress_stats()
    
    return jsonify(stats)

@projects_bp.route('/api/<int:id>/pages')
def api_project_pages(id):
    """API endpoint to get pages for a project"""
    project = Project.query.get_or_404(id)
    pages = Page.query.filter_by(project_id=id).order_by(Page.page_number).all()
    
    pages_data = [{
        'id': page.id,
        'page_number': page.page_number,
        'notes': page.notes
    } for page in pages]
    
    return jsonify({
        'status': 'success',
        'project_id': id,
        'pages': pages_data
    })

@projects_bp.route('/<int:project_id>/next-page')
def get_next_page(project_id):
    """Get the next unprocessed page for a project"""
    project = Project.query.get_or_404(project_id)
    
    # Get all pages ordered by page number
    pages = Page.query.filter_by(project_id=project_id).order_by(Page.page_number).all()
    
    # Find the first page that has no tasks or only failed/incomplete tasks
    next_page = None
    for page in pages:
        latest_task = None
        if page.tasks:
            latest_task = sorted(page.tasks, key=lambda t: t.start_time, reverse=True)[0]
        
        # If page has no tasks or the latest task is not completed/processed
        if not latest_task or latest_task.work_status not in ['processed', 'reviewed']:
            next_page = page
            break
    
    if next_page:
        return jsonify({
            'success': True,
            'page': {
                'id': next_page.id,
                'page_number': next_page.page_number,
                'image_count': len(next_page.images)
            }
        })
    else:
        return jsonify({
            'success': False,
            'message': 'No unprocessed pages found'
        })

@projects_bp.route('/<int:project_id>/dictionary')
def project_dictionary(project_id):
    """View all dictionary entries for a project"""
    project = Project.query.get_or_404(project_id)
    
    # Get all dictionary entries for the project
    entries = DictionaryEntry.query.filter_by(project_id=project_id).all()
    
    return render_template('projects/dictionary.html', 
                          project=project, 
                          entries=entries)

@projects_bp.route('/<int:project_id>/page/<int:page_id>/dictionary')
def page_dictionary(project_id, page_id):
    """View dictionary entries for a specific page"""
    project = Project.query.get_or_404(project_id)
    page = Page.query.get_or_404(page_id)
    
    # Get all processing results for this page (for filtering)
    processing_results = ProcessingResult.query.join(
        Task, ProcessingResult.task_id == Task.id
    ).join(
        Prompt, ProcessingResult.prompt_id == Prompt.id
    ).filter(
        Task.page_id == page_id,
        Task.status == 'completed'  # Only show completed tasks
    ).order_by(Task.start_time.desc()).all()
    
    # Check if we're in comparison mode
    comparison_mode = request.args.get('compare', 'false').lower() == 'true'
    task_1 = None
    task_2 = None
    task_1_result = None
    task_2_result = None
    task_1_entries = []
    task_2_entries = []
    
    # Handle comparison mode
    if comparison_mode:
        task1_id = request.args.get('task1', type=int)
        task2_id = request.args.get('task2', type=int)
        
        if task1_id and task2_id:
            task_1 = Task.query.get(task1_id)
            task_2 = Task.query.get(task2_id)
            
            if task_1 and task_2:
                # Get the processing results for each task
                task_1_result = ProcessingResult.query.filter_by(task_id=task1_id).first()
                task_2_result = ProcessingResult.query.filter_by(task_id=task2_id).first()
                
                if task_1_result and task_2_result:
                    # Get entries for each task
                    task_1_entries = DictionaryEntry.query.filter_by(
                        processing_result_id=task_1_result.id
                    ).all()
                    
                    task_2_entries = DictionaryEntry.query.filter_by(
                        processing_result_id=task_2_result.id
                    ).all()
    
    # Get the selected task ID from query params, or use the page's selected task by default
    selected_task_id = request.args.get('task_id', type=int) or page.selected_task_id
    
    # If no task is selected and we have results, use the latest one
    if not selected_task_id and processing_results:
        selected_task_id = processing_results[0].task_id
    
    task_stats = None
    entries = []
    task_result = None
    
    if selected_task_id:
        # Get the processing result for the selected task
        task_result = ProcessingResult.query.filter_by(task_id=selected_task_id).first()
        
        if task_result:
            # Get entries only for the selected task's processing result
            entries = DictionaryEntry.query.filter_by(
                processing_result_id=task_result.id
            ).all()
            
            # Calculate stats for the selected task
            total_entries = len(entries)
            evaluated_entries = sum(1 for entry in entries if entry.is_evaluated)
            correct_entries = sum(1 for entry in entries if entry.is_evaluated and entry.is_correct)
            
            accuracy = None
            if evaluated_entries > 0:
                accuracy = round((correct_entries / evaluated_entries) * 100)
                
            task_stats = {
                'total': total_entries,
                'evaluated': evaluated_entries,
                'correct': correct_entries,
                'accuracy': accuracy
            }
    
    return render_template(
        'projects/page_dictionary.html',
        project=project,
        page=page,
        entries=entries,
        processing_results=processing_results,
        selected_task_id=selected_task_id,
        task_stats=task_stats,
        task_result=task_result,
        comparison_mode=comparison_mode,
        task_1=task_1,
        task_2=task_2,
        task_1_result=task_1_result,
        task_2_result=task_2_result,
        task_1_entries=task_1_entries,
        task_2_entries=task_2_entries
    )

@projects_bp.route('/<int:project_id>/page/<int:page_id>/set-selected-task', methods=['POST'])
def set_selected_task(project_id, page_id):
    """Set the selected task for a page"""
    project = Project.query.get_or_404(project_id)
    page = Page.query.get_or_404(page_id)
    
    if page.project_id != project_id:
        abort(404)
    
    task_id = request.form.get('task_id', type=int)
    if not task_id:
        flash('No task selected', 'error')
        return redirect(url_for('projects.page_dictionary', project_id=project_id, page_id=page_id))
    
    # Verify the task exists and belongs to this page
    task = Task.query.get_or_404(task_id)
    if task.page_id != page_id:
        abort(400)
    
    # Set as selected task
    page.selected_task_id = task_id
    db.session.commit()
    
    flash('Selected task updated successfully', 'success')
    return redirect(url_for('projects.page_dictionary', project_id=project_id, page_id=page_id))

@projects_bp.route('/<int:project_id>/dictionary/stats')
def get_dictionary_stats(project_id):
    """Get dictionary statistics for a project."""
    project = Project.query.get_or_404(project_id)
    
    # Get all pages in the project
    pages = project.pages
    
    # Get dictionary entries from selected tasks through processing results
    entries = []
    for page in pages:
        if page.selected_task_id:
            # Get the processing result for the selected task
            processing_result = ProcessingResult.query.filter_by(task_id=page.selected_task_id).first()
            if processing_result:
                entries.extend(DictionaryEntry.query.filter_by(processing_result_id=processing_result.id).all())
    
    # Calculate statistics
    total_entries = len(entries)
    evaluated_entries = sum(1 for e in entries if e.is_evaluated)
    correct_entries = sum(1 for e in entries if e.is_evaluated and e.is_correct)
    incorrect_entries = sum(1 for e in entries if e.is_evaluated and not e.is_correct)
    accuracy = (correct_entries / evaluated_entries * 100) if evaluated_entries > 0 else 0
    
    return jsonify({
        'total_entries': total_entries,
        'evaluated_entries': evaluated_entries,
        'correct_entries': correct_entries,
        'incorrect_entries': incorrect_entries,
        'accuracy': round(accuracy, 1)
    })

@projects_bp.route('/<int:project_id>/dictionary/export/<format>')
def export_dictionary(project_id, format):
    """Export project dictionary in various formats."""
    project = Project.query.get_or_404(project_id)
    
    # Get field selection from query parameters
    fields = request.args.getlist('fields[]')
    if not fields:
        # Default fields if none selected
        fields = ['estonian_headword', 'german_equivalent', 'part_of_speech', 'estonian_declension',
                 'estonian_synonyms', 'german_synonyms', 'latin_explanation', 'estonian_mwu',
                 'translated_mwu', 'page_number', 'evaluation']
    
    # Get all pages in the project, ordered by page number
    pages = Page.query.filter_by(project_id=project_id).order_by(Page.page_number).all()
    
    # Get dictionary entries from selected tasks, maintaining page order
    entries = []
    for page in pages:
        if page.selected_task_id:
            # Get the processing result for the selected task
            processing_result = ProcessingResult.query.filter_by(task_id=page.selected_task_id).first()
            if processing_result:
                # Get entries for this page and sort by their order within the page
                page_entries = DictionaryEntry.query.filter_by(processing_result_id=processing_result.id).order_by(DictionaryEntry.order).all()
                entries.extend(page_entries)
    
    if format == 'json':
        # Export as JSON
        entries_data = []
        for entry in entries:
            entry_data = {}
            for field in fields:
                if field == 'page_number':
                    entry_data[field] = entry.page.page_number if entry.page else None
                elif field == 'evaluation':
                    entry_data[field] = 'correct' if entry.is_correct else ('incorrect' if entry.is_evaluated else 'unevaluated')
                elif hasattr(entry, field):
                    entry_data[field] = getattr(entry, field)
            entries_data.append(entry_data)
        
        response = jsonify(entries_data)
        response.headers['Content-Disposition'] = f'attachment; filename={project.name}_dictionary.json'
        return response
        
    elif format == 'csv':
        # Export as CSV
        output = StringIO()
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        
        for entry in entries:
            row = {}
            for field in fields:
                if field == 'page_number':
                    row[field] = entry.page.page_number if entry.page else None
                elif field == 'evaluation':
                    row[field] = 'correct' if entry.is_correct else ('incorrect' if entry.is_evaluated else 'unevaluated')
                elif hasattr(entry, field):
                    row[field] = getattr(entry, field)
            writer.writerow(row)
            
        output.seek(0)
        return Response(
            output.getvalue(),
            mimetype='text/csv',
            headers={'Content-Disposition': f'attachment; filename={project.name}_dictionary.csv'}
        )
        
    elif format == 'markdown':
        # Export as Markdown
        markdown = f"# {project.name} - Dictionary\n\n"
        
        # Add metadata
        markdown += f"- Total Entries: {len(entries)}\n"
        markdown += f"- Export Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
        
        # Group entries by page
        current_page = None
        for entry in entries:
            if entry.page and entry.page.page_number != current_page:
                current_page = entry.page.page_number
                markdown += f"\n## Page {current_page}\n\n"
            
            markdown += f"### {entry.estonian_headword}\n\n"
            
            # Add other fields
            for field in fields:
                if field != 'estonian_headword':  # Skip headword as it's already the header
                    if field == 'german_equivalent' and hasattr(entry, field):
                        markdown += f"**German:** {getattr(entry, field)}\n\n"
                    elif field == 'part_of_speech' and getattr(entry, field):
                        markdown += f"*{getattr(entry, field)}*\n\n"
                    elif field == 'page_number':
                        continue  # Skip page number as it's in the section header
                    elif field == 'evaluation':
                        status = 'correct' if entry.is_correct else ('incorrect' if entry.is_evaluated else 'unevaluated')
                        markdown += f"*Status: {status}*\n\n"
                    elif hasattr(entry, field) and getattr(entry, field):
                        field_name = field.replace('_', ' ').title()
                        markdown += f"**{field_name}:** {getattr(entry, field)}\n\n"
            
            markdown += "---\n\n"
        
        return Response(
            markdown,
            mimetype='text/markdown',
            headers={'Content-Disposition': f'attachment; filename={project.name}_dictionary.md'}
        )
        
    return jsonify({'error': 'Invalid format'}), 400

@projects_bp.route('/<int:project_id>/page/<int:page_id>/dictionary/export/<format>')
def export_page_dictionary(project_id, page_id, format):
    """Export dictionary entries for a specific page in various formats."""
    project = Project.query.get_or_404(project_id)
    page = Page.query.get_or_404(page_id)
    
    if page.project_id != project_id:
        abort(404)
    
    # Get the selected task ID from query params, or use the page's selected task by default
    selected_task_id = request.args.get('task_id', type=int) or page.selected_task_id
    entries = []
    
    if selected_task_id:
        # Get the processing result for the selected task
        task_result = ProcessingResult.query.filter_by(task_id=selected_task_id).first()
        if task_result:
            entries = DictionaryEntry.query.filter_by(processing_result_id=task_result.id).all()
    
    if format == 'json':
        # Export as JSON
        entries_data = [entry.to_dict() for entry in entries]
        return jsonify(entries_data)
        
    elif format == 'csv':
        # Export as CSV
        output = StringIO()
        writer = csv.writer(output)
        
        # Write header
        writer.writerow([
            'estonian_headword',
            'estonian_synonyms',
            'german_equivalent',
            'german_synonyms',
            'latin_explanation',
            'part_of_speech',
            'estonian_declension',
            'estonian_mwu',
            'translated_mwu',
            'is_evaluated',
            'is_correct'
        ])
        
        # Write entries
        for entry in entries:
            writer.writerow([
                entry.estonian_headword,
                entry.estonian_synonyms,
                entry.german_equivalent,
                entry.german_synonyms,
                entry.latin_explanation,
                entry.part_of_speech,
                entry.estonian_declension,
                entry.estonian_mwu,
                entry.translated_mwu,
                'Yes' if entry.is_evaluated else 'No',
                'Yes' if entry.is_evaluated and entry.is_correct else 'No'
            ])
        
        # Create response
        output.seek(0)
        return output.getvalue(), 200, {
            'Content-Type': 'text/csv',
            'Content-Disposition': f'attachment; filename=page_{page_id}_dictionary.csv'
        }
        
    elif format == 'markdown':
        # Export as Markdown
        markdown = f"# Page {page.page_number} - Dictionary\n\n"
        
        # Sort entries by headword
        entries = sorted(entries, key=lambda x: x.estonian_headword)
        
        for entry in entries:
            markdown += f"## {entry.estonian_headword}\n\n"
            
            if entry.part_of_speech:
                markdown += f"*{entry.part_of_speech}*\n\n"
                
            if entry.estonian_declension:
                markdown += f"**Declension:** {entry.estonian_declension}\n\n"
                
            if entry.estonian_synonyms:
                markdown += f"**Estonian Synonyms:** {entry.estonian_synonyms}\n\n"
                
            markdown += f"**German:** {entry.german_equivalent}\n\n"
            
            if entry.german_synonyms:
                markdown += f"**German Synonyms:** {entry.german_synonyms}\n\n"
                
            if entry.latin_explanation:
                markdown += f"**Latin:** {entry.latin_explanation}\n\n"
                
            if entry.estonian_mwu:
                markdown += f"**Examples:** {entry.estonian_mwu}\n\n"
                
            if entry.translated_mwu:
                markdown += f"**Translated Examples:** {entry.translated_mwu}\n\n"
                
            if entry.is_evaluated:
                status = "✅ Correct" if entry.is_correct else "❌ Incorrect"
                markdown += f"**Status:** {status}\n\n"
                
            markdown += "---\n\n"
        
        # Create response
        return markdown, 200, {
            'Content-Type': 'text/markdown',
            'Content-Disposition': f'attachment; filename=page_{page_id}_dictionary.md'
        }
    
    # Invalid format
    flash('Invalid export format.', 'danger')
    return redirect(url_for('projects.page_dictionary', project_id=project_id, page_id=page_id))

@projects_bp.route('/<int:project_id>/upload-images', methods=['POST'])
def upload_images(project_id):
    """Handle image uploads for a project"""
    project = Project.query.get_or_404(project_id)
    
    if 'files[]' not in request.files:
        return jsonify({'success': False, 'message': 'No files uploaded'})
    
    files = request.files.getlist('files[]')
    page_numbers = request.form.getlist('page_numbers[]')
    
    if len(files) != len(page_numbers):
        return jsonify({'success': False, 'message': 'Mismatch between files and page numbers'})
    
    try:
        for file, page_number in zip(files, page_numbers):
            # Create the page
            page = Page(
                project_id=project_id,
                page_number=int(page_number)
            )
            db.session.add(page)
            db.session.flush()  # Get the page ID
            
            # Save the file
            if file and file.filename:
                original_filename = file.filename
                filename = secure_filename(original_filename)
                file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)
                
                # Create the image record with original filename
                image = Image(
                    filename=filename,
                    original_filename=original_filename,
                    upload_date=datetime.utcnow(),
                    file_size=os.path.getsize(file_path),
                    mime_type=file.content_type,
                    page_id=page.id
                )
                db.session.add(image)
        
        # Update project's updated_date
        project.updated_date = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Successfully uploaded {len(files)} images'
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f'Error uploading images: {str(e)}')
        return jsonify({
            'success': False,
            'message': 'An error occurred while uploading images'
        })

@projects_bp.route('/<int:project_id>/page/<int:page_id>/task/<int:task_id>/delete', methods=['POST'])
def delete_task(project_id, page_id, task_id):
    """Delete a task and its associated processing results"""
    # Verify the task exists and belongs to the project/page
    task = Task.query.filter_by(
        id=task_id,
        project_id=project_id,
        page_id=page_id
    ).first_or_404()
    
    # If this was the selected task for the page, unset it
    page = Page.query.get_or_404(page_id)
    if page.selected_task_id == task_id:
        page.selected_task_id = None
        
    # Delete associated processing results first (which will cascade delete dictionary entries)
    ProcessingResult.query.filter_by(task_id=task_id).delete()
    
    # Delete the task
    db.session.delete(task)
    db.session.commit()
    
    return jsonify({'success': True})

@projects_bp.route('/<int:project_id>/page/<int:page_id>/task/<int:task_id>/details')
def task_details(project_id, page_id, task_id):
    """Get detailed information about a task"""
    # Verify the task exists and belongs to the project/page
    task = Task.query.filter_by(
        id=task_id,
        project_id=project_id,
        page_id=page_id
    ).first_or_404()
    
    # Get the processing result if it exists
    processing_result = ProcessingResult.query.filter_by(task_id=task_id).first()
    
    # Calculate duration if the task is completed
    duration = None
    if task.end_time and task.start_time:
        duration = str(task.end_time - task.start_time)
    
    # Get the prompt information
    prompt = Prompt.query.get(task.prompt_id) if task.prompt_id else None
    
    response_data = {
        'status': task.status.value if task.status else 'unknown',
        'start_time': task.start_time.isoformat() if task.start_time else None,
        'end_time': task.end_time.isoformat() if task.end_time else None,
        'duration': duration,
        'prompt_name': prompt.name if prompt else 'Unknown',
        'model': prompt.model if prompt else None,
        'error_message': task.error_message if task.error_message else None
    }
    
    return jsonify(response_data) 