from flask import Blueprint, render_template, redirect, url_for, request, flash, session
from app.models.models import Image, ProcessingResult, Prompt, Project, Task, Page, TaskStatus, DictionaryEntry
from sqlalchemy import or_
from app import db

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    """Homepage route."""
    return redirect(url_for('projects.index'))

@main_bp.route('/drafts', defaults={'content_type': None})
@main_bp.route('/drafts/<content_type>')
def drafts(content_type):
    """View for displaying unassigned content (draft area)."""
    
    # Get counts for sidebar
    unassigned_images_count = Image.query.filter_by(page_id=None).count()
    prompts_count = Prompt.query.count()
    unassigned_tasks_count = Task.query.filter_by(project_id=None).count()
    
    if content_type == 'images':
        # Show unassigned images
        images = Image.query.filter_by(page_id=None)\
            .order_by(Image.upload_date.desc())\
            .all()
        return render_template('drafts/images.html', 
                              images=images,
                              unassigned_images_count=unassigned_images_count,
                              prompts_count=prompts_count,
                              unassigned_tasks_count=unassigned_tasks_count)
    
    elif content_type == 'prompts':
        # Show prompts
        prompts = Prompt.query.order_by(Prompt.updated_date.desc()).all()
        return render_template('drafts/prompts.html', 
                              prompts=prompts,
                              unassigned_images_count=unassigned_images_count,
                              prompts_count=prompts_count,
                              unassigned_tasks_count=unassigned_tasks_count)
    
    elif content_type == 'tasks':
        # Show unassigned tasks
        tasks = Task.query.filter_by(project_id=None)\
            .order_by(Task.start_time.desc())\
            .all()
        return render_template('drafts/tasks.html', 
                              tasks=tasks,
                              unassigned_images_count=unassigned_images_count,
                              prompts_count=prompts_count,
                              unassigned_tasks_count=unassigned_tasks_count)
    
    # Default view - show dashboard of unassigned content
    recent_images = Image.query.filter_by(page_id=None)\
        .order_by(Image.upload_date.desc())\
        .limit(5)\
        .all()
    
    recent_prompts = Prompt.query.filter_by()\
        .order_by(Prompt.updated_date.desc())\
        .limit(5)\
        .all()
    
    recent_tasks = Task.query.filter_by(project_id=None)\
        .order_by(Task.start_time.desc())\
        .limit(10)\
        .all()
    
    return render_template('drafts/index.html',
                          unassigned_images_count=unassigned_images_count,
                          prompts_count=prompts_count,
                          unassigned_tasks_count=unassigned_tasks_count,
                          recent_images=recent_images,
                          recent_prompts=recent_prompts,
                          recent_tasks=recent_tasks)

@main_bp.route('/batch_assign/tasks', methods=['GET'])
def batch_assign_tasks():
    """Form for batch assigning multiple tasks to a project."""
    task_ids = request.args.get('ids', '')
    
    if not task_ids:
        flash('No tasks selected for assignment.', 'warning')
        return redirect(url_for('main.drafts', content_type='tasks'))
    
    # Parse task IDs
    try:
        task_id_list = [int(id) for id in task_ids.split(',')]
    except ValueError:
        flash('Invalid task IDs provided.', 'danger')
        return redirect(url_for('main.drafts', content_type='tasks'))
    
    # Get task objects
    selected_tasks = Task.query.filter(Task.id.in_(task_id_list)).all()
    
    if not selected_tasks:
        flash('No valid tasks found with the provided IDs.', 'warning')
        return redirect(url_for('main.drafts', content_type='tasks'))
    
    # Get all projects for dropdown
    projects = Project.query.order_by(Project.name).all()
    
    return render_template('drafts/batch_assign_tasks.html',
                          selected_tasks=selected_tasks,
                          task_ids=task_ids,
                          projects=projects)

@main_bp.route('/settings')
def settings():
    """Settings page."""
    return render_template('settings.html')

@main_bp.route('/api-key', methods=['GET', 'POST'])
def api_key():
    """Manage API key"""
    if request.method == 'POST':
        api_key = request.form.get('api_key')
        if api_key:
            session['api_key'] = api_key
            flash('API key saved successfully', 'success')
        else:
            session.pop('api_key', None)
            flash('API key removed', 'info')
        return redirect(request.referrer or url_for('main.index'))
    
    return render_template('main/api_key.html', has_api_key='api_key' in session) 