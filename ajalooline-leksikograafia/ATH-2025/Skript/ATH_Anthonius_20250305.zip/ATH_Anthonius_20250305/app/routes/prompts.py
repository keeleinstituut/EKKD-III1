from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from app import db
from app.models.models import Prompt, Project
from datetime import datetime
import os
import sys

# Add the parent directory to sys.path to import the DictionaryParser
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from WIP_MJ_20250301_helle_12 import DictionaryParser

prompts_bp = Blueprint('prompts', __name__, url_prefix='/prompts')

@prompts_bp.route('/')
def index():
    """List all prompts."""
    prompts = Prompt.query.order_by(Prompt.created_date.desc()).all()
    return render_template('prompts/index.html', prompts=prompts)

@prompts_bp.route('/create', methods=['GET', 'POST'])
def create():
    """Create a new prompt."""
    if request.method == 'POST':
        name = request.form.get('name')
        content = request.form.get('content')
        model = request.form.get('model')
        max_tokens = request.form.get('max_tokens', type=int)
        enable_thinking = request.form.get('enable_thinking') == 'on'
        temperature = request.form.get('temperature', type=float)
        project_id = request.form.get('project_id', type=int)
        
        if not name or not content:
            flash('Name and content are required', 'error')
            return render_template('prompts/create.html', 
                                  name=name, 
                                  content=content, 
                                  model=model, 
                                  max_tokens=max_tokens, 
                                  enable_thinking=enable_thinking,
                                  temperature=temperature,
                                  projects=Project.query.order_by(Project.name).all())
        
        # Force temperature to 1.0 if thinking is enabled
        if enable_thinking:
            temperature = 1.0
        
        prompt = Prompt(
            name=name,
            content=content,
            model=model or "claude-3-7-sonnet-20250219",
            max_tokens=max_tokens or 64000,
            enable_thinking=enable_thinking,
            temperature=temperature or 0.7,
            project_id=project_id
        )
        
        try:
            prompt.validate()
            db.session.add(prompt)
            db.session.commit()
            flash('Prompt created successfully', 'success')
            if project_id:
                return redirect(url_for('projects.view', id=project_id))
            return redirect(url_for('prompts.index'))
        except ValueError as e:
            flash(str(e), 'error')
            return render_template('prompts/create.html', 
                                  name=name, 
                                  content=content, 
                                  model=model, 
                                  max_tokens=max_tokens, 
                                  enable_thinking=enable_thinking,
                                  temperature=temperature,
                                  projects=Project.query.order_by(Project.name).all())
    
    # Create mode - GET request
    # Get the default prompt from DictionaryParser to pre-fill
    try:
        # Create a DictionaryParser with a dummy API key just to get the default prompt
        parser = DictionaryParser(api_key="dummy_key_for_prompt")
        default_prompt = parser.system_prompt
    except:
        default_prompt = ""  # Fallback if we can't get the default prompt
    
    # Get all projects for the dropdown
    projects = Project.query.order_by(Project.name).all()
    
    # Get project_id from query parameter if provided
    project_id = request.args.get('project_id', type=int)
    
    return render_template('prompts/create.html', 
                          name="", 
                          content=default_prompt, 
                          model="claude-3-7-sonnet-20250219", 
                          max_tokens=64000, 
                          enable_thinking=False,
                          temperature=0.7,
                          projects=projects,
                          selected_project_id=project_id)

@prompts_bp.route('/<int:prompt_id>')
def view(prompt_id):
    """View a prompt."""
    prompt = Prompt.query.get_or_404(prompt_id)
    return render_template('prompts/view.html', prompt=prompt)

@prompts_bp.route('/<int:prompt_id>/edit', methods=['GET', 'POST'])
def edit(prompt_id):
    """Edit a prompt."""
    prompt = Prompt.query.get_or_404(prompt_id)
    
    if request.method == 'POST':
        name = request.form.get('name', prompt.name)  # Keep existing name if not provided
        content = request.form.get('content')
        model = request.form.get('model')
        max_tokens = request.form.get('max_tokens', type=int)
        enable_thinking = request.form.get('enable_thinking') == 'on'
        temperature = request.form.get('temperature', type=float)
        
        if not content:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': 'Content is required'})
            flash('Content is required', 'error')
            return render_template('prompts/edit.html', prompt=prompt)
        
        # Force temperature to 1.0 if thinking is enabled
        if enable_thinking:
            temperature = 1.0
        
        prompt.name = name  # Make sure we're updating the name
        prompt.content = content
        prompt.model = model or "claude-3-7-sonnet-20250219"
        prompt.max_tokens = max_tokens or 64000
        prompt.enable_thinking = enable_thinking
        prompt.temperature = temperature or 0
        
        try:
            prompt.validate()
            db.session.commit()
            
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({
                    'success': True,
                    'message': 'Prompt updated successfully',
                    'name': prompt.name,
                    'content': prompt.content,
                    'model': prompt.model,
                    'max_tokens': prompt.max_tokens,
                    'enable_thinking': prompt.enable_thinking,
                    'temperature': prompt.temperature
                })
                
            flash('Prompt updated successfully', 'success')
            return redirect(url_for('prompts.view', prompt_id=prompt.id))
        except ValueError as e:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': str(e)})
            flash(str(e), 'error')
            return render_template('prompts/edit.html', prompt=prompt)
    
    # Edit mode - GET request
    return render_template('prompts/edit.html', prompt=prompt)

@prompts_bp.route('/<int:prompt_id>/delete', methods=['POST'])
def delete(prompt_id):
    """Delete a prompt."""
    prompt = Prompt.query.get_or_404(prompt_id)
    
    # Check if prompt is in use
    if prompt.processing_results:
        flash('Cannot delete prompt that has been used for processing', 'error')
        return redirect(url_for('prompts.view', prompt_id=prompt.id))
    
    db.session.delete(prompt)
    db.session.commit()
    
    flash('Prompt deleted successfully', 'success')
    return redirect(url_for('prompts.index'))

@prompts_bp.route('/prompts/assign/<int:id>', methods=['POST'])
def assign(id):
    prompt = Prompt.query.get_or_404(id)
    project_id = request.form.get('project_id')
    
    if not project_id:
        flash('Project is required for assignment.', 'error')
        return redirect(url_for('drafts.prompts'))
        
    project = Project.query.get_or_404(project_id)
    prompt.project = project
    prompt.updated_date = datetime.utcnow()
    
    try:
        db.session.commit()
        flash(f'Prompt "{prompt.name}" assigned to project "{project.name}".', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error assigning prompt to project.', 'error')
        
    return redirect(url_for('drafts.prompts'))

@prompts_bp.route('/batch_assign', methods=['POST'])
def batch_assign():
    prompt_ids = request.form.getlist('prompt_ids[]')
    project_id = request.form.get('project_id')
    
    if not prompt_ids:
        flash('No prompts selected for assignment.', 'error')
        return redirect(url_for('drafts.prompts'))
        
    if not project_id:
        flash('Project is required for assignment.', 'error')
        return redirect(url_for('drafts.prompts'))
    
    project = Project.query.get_or_404(project_id)
    assigned_count = 0
    
    try:
        for prompt_id in prompt_ids:
            prompt = Prompt.query.get(prompt_id)
            if prompt:
                prompt.project = project
                prompt.updated_date = datetime.utcnow()
                assigned_count += 1
        
        db.session.commit()
        flash(f'{assigned_count} prompts assigned to project "{project.name}".', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error assigning prompts to project.', 'error')
    
    return redirect(url_for('drafts.prompts'))

@prompts_bp.route('/get_prompt_content')
def get_prompt_content():
    """Get prompt content for the preview in modal."""
    prompt_id = request.args.get('prompt_id', type=int)
    if not prompt_id:
        return jsonify({'success': False, 'message': 'Prompt ID is required'})
    
    prompt = Prompt.query.get_or_404(prompt_id)
    
    return jsonify({
        'success': True,
        'content': prompt.content,
        'model': prompt.model,
        'max_tokens': prompt.max_tokens,
        'enable_thinking': prompt.enable_thinking,
        'temperature': prompt.temperature
    }) 