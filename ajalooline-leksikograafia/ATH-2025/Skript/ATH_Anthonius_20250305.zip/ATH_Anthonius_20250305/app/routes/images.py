import os
import uuid
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app, abort, jsonify, send_file
from werkzeug.utils import secure_filename
from app import db
from app.models.models import Image, Project, Page
import datetime

images_bp = Blueprint('images', __name__, url_prefix='/images')

def allowed_file(filename):
    """Check if the file has an allowed extension."""
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'tif', 'tiff'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@images_bp.route('/')
def index():
    """List all uploaded images."""
    # Get projects for filtering
    projects = Project.query.order_by(Project.name).all()
    
    # Apply project filter if specified
    project_id = request.args.get('project_id', type=int)
    page_id = request.args.get('page_id', type=int)
    selected_project = None
    selected_page = None
    
    if project_id:
        selected_project = Project.query.get(project_id)
    
    if page_id:
        selected_page = Page.query.get(page_id)
        if selected_page and (not selected_project or selected_page.project_id != selected_project.id):
            selected_project = selected_page.project
    
    # Build the query
    query = Image.query
    
    if selected_page:
        query = query.filter_by(page_id=selected_page.id)
    elif selected_project:
        # Get all page IDs for this project
        page_ids = [page.id for page in Page.query.filter_by(project_id=selected_project.id).all()]
        if page_ids:
            query = query.filter(Image.page_id.in_(page_ids))
        else:
            # If no pages exist for this project, don't return any images
            images = []
            return render_template('images/index.html', 
                               images=images, 
                               projects=projects,
                               selected_project=selected_project,
                               selected_page=selected_page)
    
    images = query.order_by(Image.upload_date.desc()).all()
    return render_template('images/index.html', 
                          images=images, 
                          projects=projects,
                          selected_project=selected_project,
                          selected_page=selected_page)

@images_bp.route('/upload', methods=['GET', 'POST'])
def upload():
    """Handle image upload."""
    # Get projects and pages for selection
    projects = Project.query.order_by(Project.name).all()
    
    # Get project_id and page_id from query params or form
    project_id = request.args.get('project_id', type=int) or request.form.get('project_id', type=int)
    page_id = request.args.get('page_id', type=int) or request.form.get('page_id', type=int)
    
    selected_project = None
    pages = []
    
    if project_id:
        selected_project = Project.query.get(project_id)
        if selected_project:
            pages = Page.query.filter_by(project_id=project_id).order_by(Page.page_number).all()
    
    if request.method == 'POST':
        # Check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part', 'error')
            return redirect(request.url)
        
        files = request.files.getlist('file')
        
        # Get page_id from form
        page_id = request.form.get('page_id', type=int)
        page_number = None
        
        # If page_id is provided, get the page object to associate with the image
        page = None
        if page_id:
            page = Page.query.get(page_id)
            if page:
                page_number = page.page_number
        
        if not files or files[0].filename == '':
            flash('No selected file', 'error')
            return redirect(request.url)
        
        uploaded_images = []
        for file in files:
            if file and allowed_file(file.filename):
                # Create a unique filename
                original_filename = secure_filename(file.filename)
                file_extension = original_filename.rsplit('.', 1)[1].lower()
                unique_filename = f"{uuid.uuid4().hex}.{file_extension}"
                
                # Save the file
                file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], unique_filename)
                file.save(file_path)
                
                # Create a database record
                image = Image(
                    filename=unique_filename,
                    original_filename=original_filename,
                    file_size=os.path.getsize(file_path),
                    mime_type=file.content_type,
                    page_number=page_number,
                    page_id=page_id if page else None
                )
                
                db.session.add(image)
                uploaded_images.append(original_filename)
            else:
                flash(f'File {file.filename} has an invalid extension', 'error')
        
        if uploaded_images:
            db.session.commit()
            flash(f'Successfully uploaded {len(uploaded_images)} image(s)', 'success')
            
            # If a page was specified, redirect to the page view
            if page:
                return redirect(url_for('projects.view_page', project_id=page.project_id, page_id=page.id))
            # If a project was specified, redirect to the project view
            elif project_id:
                return redirect(url_for('projects.view', id=project_id))
            else:
                return redirect(url_for('images.index'))
    
    return render_template('images/upload.html', 
                         projects=projects, 
                         pages=pages, 
                         selected_project=selected_project, 
                         selected_page_id=page_id)

@images_bp.route('/<int:id>')
def view(id):
    """View an image and its details."""
    image = Image.query.get_or_404(id)
    return render_template('images/view.html', image=image)

@images_bp.route('/<int:image_id>/update_page', methods=['POST'])
def update_page(image_id):
    """Associate an image with a page."""
    image = Image.query.get_or_404(image_id)
    
    page_id = request.form.get('page_id', type=int)
    page = None
    if page_id:
        page = Page.query.get(page_id)
    
    if page:
        image.page_id = page.id
        image.page_number = page.page_number
        db.session.commit()
        flash(f'Image associated with page {page.page_number}', 'success')
        
        # Redirect to the page view
        return redirect(url_for('projects.view_page', project_id=page.project_id, page_id=page.id))
    else:
        flash('Invalid page selected', 'error')
    
    return redirect(url_for('images.view', id=image_id))

@images_bp.route('/<int:image_id>/update_page_number', methods=['POST'])
def update_page_number(image_id):
    """Update the page number for an image (legacy support)."""
    image = Image.query.get_or_404(image_id)
    
    try:
        page_number = int(request.form.get('page_number', 0))
        image.page_number = page_number
        db.session.commit()
        flash(f'Page number updated to {page_number}', 'success')
    except ValueError:
        flash('Invalid page number', 'error')
    
    return redirect(url_for('images.view', id=image_id))

@images_bp.route('/assign/<int:id>', methods=['GET', 'POST'])
def assign(id):
    """Assign an image to a project/page."""
    image = Image.query.get_or_404(id)
    projects = Project.query.order_by(Project.name).all()
    
    if request.method == 'POST':
        project_id = request.form.get('project_id', type=int)
        page_id = request.form.get('page_id', type=int)
        
        if not project_id:
            flash('Please select a project.', 'danger')
            return redirect(url_for('images.assign', id=id))
        
        project = Project.query.get(project_id)
        if not project:
            flash('Selected project not found.', 'danger')
            return redirect(url_for('images.assign', id=id))
        
        # Update image with project and page if provided
        image.project_id = project_id
        
        if page_id:
            page = Page.query.get(page_id)
            if page and page.project_id == project_id:
                image.page_id = page_id
        
        db.session.commit()
        flash(f'Image successfully assigned to project "{project.name}".', 'success')
        return redirect(url_for('images.view', id=id))
    
    # Get pages for the initial project (if image already has a project)
    initial_pages = []
    if image.project_id:
        initial_pages = Page.query.filter_by(project_id=image.project_id).order_by(Page.page_number).all()
    
    return render_template('images/assign.html', 
                          image=image, 
                          projects=projects,
                          initial_pages=initial_pages)

@images_bp.route('/batch_assign', methods=['GET', 'POST'])
def batch_assign():
    """Batch assign multiple images to a project/page."""
    if request.method == 'POST':
        # Get image ids from form
        image_ids_str = request.form.get('image_ids', '')
        project_id = request.form.get('project_id', type=int)
        page_id = request.form.get('page_id', type=int)
        
        if not image_ids_str or not project_id:
            flash('Missing required parameters.', 'danger')
            return redirect(url_for('main.drafts', content_type='images'))
        
        # Validate project
        project = Project.query.get(project_id)
        if not project:
            flash('Selected project not found.', 'danger')
            return redirect(url_for('main.drafts', content_type='images'))
        
        # Parse image IDs
        try:
            image_ids = [int(id) for id in image_ids_str.split(',')]
        except ValueError:
            flash('Invalid image IDs provided.', 'danger')
            return redirect(url_for('main.drafts', content_type='images'))
        
        # Validate page if provided
        page = None
        if page_id:
            page = Page.query.get(page_id)
            if not page or page.project_id != project_id:
                flash('Selected page is not valid for the chosen project.', 'danger')
                return redirect(url_for('main.drafts', content_type='images'))
        
        # Update images
        assigned_count = 0
        for image_id in image_ids:
            image = Image.query.get(image_id)
            if image:
                image.project_id = project_id
                if page_id:
                    image.page_id = page_id
                assigned_count += 1
        
        if assigned_count > 0:
            db.session.commit()
            flash(f'Successfully assigned {assigned_count} images to project "{project.name}".', 'success')
        else:
            flash('No images were assigned. The selected images may no longer exist.', 'warning')
        
        return redirect(url_for('main.drafts', content_type='images'))
    
    # Handle GET request (form display)
    image_ids = request.args.get('ids', '')
    
    if not image_ids:
        flash('No images selected for assignment.', 'warning')
        return redirect(url_for('main.drafts', content_type='images'))
    
    # Parse image IDs
    try:
        image_id_list = [int(id) for id in image_ids.split(',')]
    except ValueError:
        flash('Invalid image IDs provided.', 'danger')
        return redirect(url_for('main.drafts', content_type='images'))
    
    # Get image objects
    selected_images = Image.query.filter(Image.id.in_(image_id_list)).all()
    
    if not selected_images:
        flash('No valid images found with the provided IDs.', 'warning')
        return redirect(url_for('main.drafts', content_type='images'))
    
    # Get all projects for dropdown
    projects = Project.query.order_by(Project.name).all()
    
    return render_template('images/batch_assign.html',
                          selected_images=selected_images,
                          image_ids=image_ids,
                          projects=projects)

@images_bp.route('/delete/<int:id>')
def delete(id):
    """Delete an image."""
    image = Image.query.get_or_404(id)
    
    # Store file path for deletion after database record is removed
    file_path = image.file_path
    
    # If image has a project, redirect back to the project after deletion
    project_id = image.project_id
    
    # Check if image has any tasks
    if image.tasks:
        for task in image.tasks:
            db.session.delete(task)
    
    # Delete the image record
    db.session.delete(image)
    db.session.commit()
    
    # Remove the actual file
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
    except Exception as e:
        flash(f'Image record deleted, but could not delete file: {str(e)}', 'warning')
    
    flash('Image successfully deleted.', 'success')
    
    if project_id:
        return redirect(url_for('projects.view', id=project_id))
    else:
        return redirect(url_for('main.drafts', content_type='images'))

@images_bp.route('/serve/<int:id>')
@images_bp.route('/<int:id>/serve')
def serve(id):
    """Serve an image file."""
    size = request.args.get('size', 'original')
    
    image = Image.query.get_or_404(id)
    file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], image.filename)
    
    if not os.path.exists(file_path):
        abort(404)
    
    # For now, just serve the original file regardless of size parameter
    # TODO: Implement thumbnail generation based on size parameter
    # This could use a library like Pillow to generate and cache thumbnails
    # Example sizes: 'thumbnail', 'medium', 'large'
    return send_file(file_path, mimetype=image.mime_type) 