/**
 * Dictionary Parser Platform
 * Main JavaScript file for common functionality
 */

// Wait for DOM content to be loaded
document.addEventListener('DOMContentLoaded', function() {
    // Set active class for current navigation item
    setActiveNavItem();
    
    // Initialize Bootstrap components
    initBootstrapComponents();
    
    // Set up alerts to auto-dismiss
    setupAutoDismissAlerts();
    
    // Update footer year
    updateFooterYear();
    
    // Set up tasks monitoring
    setupTasksMonitoring();
});

// Set active class for the current navigation item based on URL
function setActiveNavItem() {
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPath || 
            (href !== '/' && currentPath.startsWith(href)) ||
            (currentPath === '/' && href === '/')) {
            link.classList.add('active');
        }
    });
}

// Initialize Bootstrap tooltips and popovers
function initBootstrapComponents() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
}

// Set up alerts to auto-dismiss after 5 seconds
function setupAutoDismissAlerts() {
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(alert => {
        setTimeout(() => {
            if (alert.parentNode) {
                var bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }
        }, 5000);
    });
}

// Update footer year
function updateFooterYear() {
    const yearElement = document.getElementById('current-year');
    if (yearElement) {
        yearElement.textContent = new Date().getFullYear();
    }
}

// Set up tasks monitoring to update the active tasks badge in the navbar
function setupTasksMonitoring() {
    const tasksBadge = document.querySelector('.active-tasks-count');
    if (!tasksBadge) return;
    
    // Check for active tasks every 10 seconds
    const checkInterval = 10000; // 10 seconds
    
    function checkActiveTasks() {
        fetch('/tasks/api/active')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (!data.success) {
                    throw new Error(data.error || 'Unknown error');
                }
                const count = data.tasks ? data.tasks.length : 0;
                updateTasksBadge(count);
            })
            .catch(error => {
                console.error('Error checking active tasks:', error);
            });
    }
    
    function updateTasksBadge(count) {
        if (count > 0) {
            tasksBadge.textContent = count;
            tasksBadge.style.display = 'inline-block';
        } else {
            tasksBadge.style.display = 'none';
        }
    }
    
    // Initial check
    checkActiveTasks();
    
    // Set up interval for checking
    setInterval(checkActiveTasks, checkInterval);
    
    // Only check when the tab is visible
    document.addEventListener('visibilitychange', function() {
        if (!document.hidden) {
            checkActiveTasks();
        }
    });
}

// Function to confirm deletion actions
function confirmDelete(message, formId) {
    if (confirm(message || 'Are you sure you want to delete this item?')) {
        document.getElementById(formId).submit();
    }
    return false;
}

// Function to preview image before upload
function previewImage(input, previewId) {
    const preview = document.getElementById(previewId);
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
        };
        
        reader.readAsDataURL(input.files[0]);
    } else {
        preview.style.display = 'none';
    }
}

// Function to toggle visibility of elements
function toggleElement(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        if (element.style.display === 'none') {
            element.style.display = 'block';
        } else {
            element.style.display = 'none';
        }
    }
}

// Function to copy text to clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(
        function() {
            alert('Copied to clipboard!');
        }, 
        function() {
            alert('Could not copy text. Please copy it manually.');
        }
    );
}

// Enable sorting tables
function enableTableSorting() {
    document.querySelectorAll('table.sortable').forEach(table => {
        const headers = table.querySelectorAll('th[data-sort]');
        headers.forEach(header => {
            header.addEventListener('click', () => {
                const column = header.dataset.sort;
                const tbody = table.querySelector('tbody');
                const rows = Array.from(tbody.querySelectorAll('tr'));
                
                // Toggle sort direction
                const sortDir = header.classList.contains('sort-asc') ? 'desc' : 'asc';
                
                // Reset all headers
                headers.forEach(h => {
                    h.classList.remove('sort-asc', 'sort-desc');
                    h.querySelector('.sort-icon')?.remove();
                });
                
                // Set current header
                header.classList.add(`sort-${sortDir}`);
                const icon = document.createElement('span');
                icon.className = 'sort-icon ms-1';
                icon.innerHTML = sortDir === 'asc' ? '↑' : '↓';
                header.appendChild(icon);
                
                // Sort rows
                rows.sort((a, b) => {
                    const aValue = a.querySelector(`td:nth-child(${column})`).textContent.trim();
                    const bValue = b.querySelector(`td:nth-child(${column})`).textContent.trim();
                    
                    if (!isNaN(aValue) && !isNaN(bValue)) {
                        return sortDir === 'asc' ? aValue - bValue : bValue - aValue;
                    }
                    
                    return sortDir === 'asc' 
                        ? aValue.localeCompare(bValue) 
                        : bValue.localeCompare(aValue);
                });
                
                // Re-append rows in new order
                rows.forEach(row => tbody.appendChild(row));
            });
        });
    });
}

// Search functionality for tables
function setupTableSearch(searchInputId, tableId) {
    const searchInput = document.getElementById(searchInputId);
    const table = document.getElementById(tableId);
    
    if (!searchInput || !table) return;
    
    searchInput.addEventListener('keyup', function() {
        const searchText = this.value.toLowerCase();
        const rows = table.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            if (text.includes(searchText)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
}

// Export table to CSV
function exportTableToCSV(tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    const rows = table.querySelectorAll('tr');
    let csv = [];
    
    for (let i = 0; i < rows.length; i++) {
        const row = [], cols = rows[i].querySelectorAll('td, th');
        
        for (let j = 0; j < cols.length; j++) {
            // Get text content, escape commas and quotes
            let text = cols[j].textContent.trim().replace(/"/g, '""');
            if (text.includes(',') || text.includes('"') || text.includes('\n')) {
                text = `"${text}"`;
            }
            row.push(text);
        }
        
        csv.push(row.join(','));
    }
    
    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (navigator.msSaveBlob) { // IE 10+
        navigator.msSaveBlob(blob, filename);
    } else {
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
} 