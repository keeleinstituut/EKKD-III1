import os
import sys
import json
import logging
from typing import Dict, List, Optional, Tuple
import base64
import time
import anthropic
from pathlib import Path

# Add the parent directory to sys.path to import the DictionaryParser
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from WIP_MJ_20250301_helle_12 import DictionaryParser

logger = logging.getLogger(__name__)

class ParserWrapper:
    """Wrapper class for dictionary parsing with Claude API"""

    def __init__(self, api_key, model="claude-3-opus-20240229", enable_thinking=True):
        """Initialize the parser with API key and options"""
        self.client = anthropic.Anthropic(api_key=api_key)
        self.model = model
        self.enable_thinking = enable_thinking
        logger.info(f"Initialized ParserWrapper with model: {model}")

    def encode_image(self, image_path):
        """Encode an image to base64 for Claude API"""
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')

    def process_image(self, image_path, prompt_content, page_number=1, max_tokens=5000):
        """Process an image with Claude API and parse the response"""
        logger.info(f"Processing image: {image_path}")
        
        if not os.path.exists(image_path):
            error_msg = f"Image file not found: {image_path}"
            logger.error(error_msg)
            raise FileNotFoundError(error_msg)
        
        base64_image = self.encode_image(image_path)
        
        # Create the system prompt
        system_prompt = """You are a Digital Humanities expert specialized in extracting and structuring dictionary entries from historical dictionaries.
Your task is to extract dictionary entries from an image of a historical German-Estonian-Latin dictionary.
"""

        if self.enable_thinking:
            system_prompt += """
Before giving me the final parsed entries, I want you to:
1. Think step by step about what you see in the image
2. Analyze the page layout and structure
3. Identify each dictionary entry and analyze its components
4. Consider any special notations or abbreviations

After your thinking, provide the parsed entries in a structured format.
"""

        # Prepare the message content with the image
        message_content = [
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/jpeg",
                    "data": base64_image
                }
            },
            {
                "type": "text",
                "text": f"This is page {page_number} from a historical German-Estonian-Latin dictionary. {prompt_content}"
            }
        ]
        
        # Make the API request
        logger.info(f"Sending request to Claude API (model: {self.model})")
        start_time = time.time()
        
        try:
            response = self.client.messages.create(
                model=self.model,
                system=system_prompt,
                max_tokens=max_tokens,
                messages=[
                    {
                        "role": "user",
                        "content": message_content
                    }
                ]
            )
            
            logger.info(f"Received response from Claude API in {time.time() - start_time:.2f} seconds")
            
            # Extract the response text
            raw_response = response.content[0].text
            
            # Extract thinking content and entries from the response
            thinking_content = ""
            entries = []
            
            # If thinking is enabled, try to extract thinking content and entries
            if self.enable_thinking:
                thinking_content, entries = self._extract_thinking_and_entries(raw_response)
            else:
                # Directly extract entries if thinking is not enabled
                entries = self._extract_entries(raw_response)
            
            logger.info(f"Successfully extracted {len(entries)} dictionary entries")
            
            return entries, thinking_content, raw_response
            
        except Exception as e:
            error_msg = f"Error processing image with Claude API: {str(e)}"
            logger.error(error_msg)
            raise Exception(error_msg)

    def _extract_thinking_and_entries(self, raw_response):
        """Extract thinking content and dictionary entries from response"""
        # Default values
        thinking_content = ""
        entries = []
        
        try:
            # Try to identify thinking and entries sections
            if "# Dictionary Entries" in raw_response:
                # Split by the marker for dictionary entries
                parts = raw_response.split("# Dictionary Entries", 1)
                thinking_content = parts[0].strip()
                entries_text = parts[1].strip()
                
                # Extract entries from the entries section
                entries = self._extract_entries(entries_text)
            else:
                # If no clear marker, try to extract entries directly
                entries = self._extract_entries(raw_response)
        except Exception as e:
            logger.warning(f"Error extracting thinking content and entries: {str(e)}")
            # Fall back to direct extraction
            entries = self._extract_entries(raw_response)
        
        return thinking_content, entries

    def _extract_entries(self, text):
        """Extract structured dictionary entries from text"""
        entries = []
        
        try:
            # Look for JSON array in the text
            if "```json" in text and "```" in text.split("```json", 1)[1]:
                # Extract JSON array from markdown code block
                json_text = text.split("```json", 1)[1].split("```", 1)[0].strip()
                entries = json.loads(json_text)
            elif "[" in text and "]" in text and "{" in text and "}" in text:
                # Try to find and parse JSON array directly
                for line in text.split("\n"):
                    if line.strip().startswith("[") and line.strip().endswith("]"):
                        entries = json.loads(line.strip())
                        break
                
                # If still no entries, try more aggressive JSON extraction
                if not entries:
                    # Find content between first [ and last ]
                    json_text = text[text.find("["):text.rfind("]")+1]
                    try:
                        entries = json.loads(json_text)
                    except:
                        pass
        except Exception as e:
            logger.error(f"Error parsing entries from response: {str(e)}")
            
        # If still no entries, try to extract them with heuristics
        if not entries:
            # This is a fallback approach when JSON parsing fails
            logger.warning("Using fallback extraction method")
            entries = self._extract_entries_with_heuristics(text)
            
        return entries

    def _extract_entries_with_heuristics(self, text):
        """Extract entries using heuristics when JSON parsing fails"""
        entries = []
        lines = text.split("\n")
        current_entry = {}
        
        for line in lines:
            line = line.strip()
            
            # Skip empty lines
            if not line:
                continue
                
            # Check if line starts a new entry (usually starts with Estonian headword)
            if line.startswith("## ") or (not current_entry and ": " in line):
                # Save previous entry if it exists
                if current_entry:
                    entries.append(current_entry)
                    
                # Start new entry
                current_entry = {"estonian_headword": line.lstrip("#").strip()}
            
            # Try to extract key-value pairs
            elif ": " in line or " - " in line:
                separator = ": " if ": " in line else " - "
                key, value = line.split(separator, 1)
                
                # Clean up key and map to our schema
                key = key.strip().lower().replace(" ", "_")
                value = value.strip()
                
                # Map common keys to our schema
                key_mapping = {
                    "estonian": "estonian_headword",
                    "german": "german_equivalent",
                    "latin": "latin_explanation",
                    "part_of_speech": "part_of_speech",
                    "pos": "part_of_speech",
                    "declension": "estonian_declension",
                    "estonian_synonyms": "estonian_synonyms",
                    "german_synonyms": "german_synonyms",
                    "examples": "estonian_mwu",
                    "translated_examples": "translated_mwu"
                }
                
                # Map the key if needed
                if key in key_mapping:
                    key = key_mapping[key]
                    
                # Add to current entry
                if key not in current_entry:
                    current_entry[key] = value
        
        # Add the last entry
        if current_entry:
            entries.append(current_entry)
            
        return entries

    def test_connection(self) -> Tuple[bool, str]:
        """Test the connection to the Claude API"""
        try:
            # Simple message to check API connection
            response = self.client.messages.create(
                model=self.model,
                max_tokens=10,
                messages=[
                    {
                        "role": "user",
                        "content": "Hello, this is a test message. Just respond with 'API connection successful'."
                    }
                ]
            )
            return True, "API connection successful"
        except Exception as e:
            logger.error(f"API connection test failed: {str(e)}")
            return False, f"API connection test failed: {str(e)}" 