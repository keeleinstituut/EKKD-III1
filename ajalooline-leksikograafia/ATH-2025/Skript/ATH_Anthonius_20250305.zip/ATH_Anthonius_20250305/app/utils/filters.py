"""
Custom Jinja2 filters for templates.
"""

from datetime import datetime

def set_dict_item(dictionary, key, value):
    """
    Set a key-value pair in a dictionary and return the modified dictionary.
    This is necessary in Jinja2 templates since dictionaries are immutable in template context.
    
    Usage example:
    {% set my_dict = my_dict | set_dict_item('new_key', 'value') %}
    """
    result = dictionary.copy()  # Create a copy to avoid modifying the original
    result[key] = value
    return result

def slice_list(items, count):
    """
    Slice a list to get the first 'count' items.
    
    Usage example:
    {% for item in items | slice(5) %}
    """
    return items[:count]

def format_date(value, format='%Y-%m-%d'):
    """Format a date according to the given format."""
    if value is None:
        return ''
    if not isinstance(value, datetime):
        # Try to parse the value as a datetime
        try:
            value = datetime.fromisoformat(str(value))
        except (ValueError, TypeError):
            return value
    return value.strftime(format)

def datetime_filter(value, format='%Y-%m-%d %H:%M'):
    """Format a datetime according to the given format."""
    if value is None:
        return ''
    if not isinstance(value, datetime):
        # Try to parse the value as a datetime
        try:
            value = datetime.fromisoformat(str(value))
        except (ValueError, TypeError):
            return value
    return value.strftime(format)

# Register all filters with the app
def register_filters(app):
    """Register custom filters with the Flask app."""
    app.jinja_env.filters['set_dict_item'] = set_dict_item
    app.jinja_env.filters['slice'] = slice_list
    app.jinja_env.filters['date'] = format_date
    app.jinja_env.filters['datetime'] = datetime_filter 