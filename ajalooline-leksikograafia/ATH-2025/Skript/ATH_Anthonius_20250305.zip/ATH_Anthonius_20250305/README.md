# Dictionary Parser Platform

A web application platform for processing dictionary images with Claude AI, managing prompts, and analyzing results.

## Features

- **Image Management**: Upload and manage book page images
- **Prompt Management**: Create, edit, and test different prompts
- **Dictionary Processing**: Process images with selected prompts and models
- **Result Analysis**: View, compare, and export dictionary entries in various formats

## Project Structure

```
.
├── app/                        # Flask application
│   ├── __init__.py             # Application factory
│   ├── models/                 # Database models
│   ├── routes/                 # Route definitions
│   ├── static/                 # Static assets
│   │   ├── css/                # CSS styles
│   │   ├── js/                 # JavaScript files
│   │   └── uploads/            # Uploaded images
│   ├── templates/              # HTML templates
│   └── utils/                  # Utility functions
├── WIP_MJ_20250301_helle_12.py # Original dictionary parser
├── .env.example                # Environment variables example
├── requirements.txt            # Python dependencies
├── run.py                      # Application entry point
└── README.md                   # Project documentation
```

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   cd dictionary-parser-platform
   ```

2. Create a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Set up environment variables:
   ```
   cp .env.example .env
   ```
   Edit `.env` and add your Claude API key and other configuration

5. Run the application:
   ```
   python run.py
   ```

6. Access the application at http://localhost:5000

## Usage

### Uploading Images

1. Navigate to "Images" > "Upload Images"
2. Select one or more book page images
3. Upload the images

### Creating Prompts

1. Navigate to "Prompts" > "Create Prompt"
2. Enter a name for your prompt
3. Modify the system prompt content
4. Configure model settings
5. Save the prompt

### Processing Images

1. Navigate to "Process"
2. Select an image and a prompt
3. Enter your Claude API key
4. Start processing
5. View the results

### Analyzing Results

1. Navigate to "Results"
2. Select a processing result to view
3. Explore the extracted dictionary entries
4. Export results in various formats (JSON, CSV, Markdown)

## Requirements

- Python 3.7+
- Flask
- Anthropic API key (Claude)