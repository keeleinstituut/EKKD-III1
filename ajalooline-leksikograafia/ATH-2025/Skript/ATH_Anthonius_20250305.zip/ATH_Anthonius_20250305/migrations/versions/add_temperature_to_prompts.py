"""add temperature to prompts

Revision ID: add_temperature_to_prompts
Revises: 9b68becb12a7
Create Date: 2024-03-05 14:55:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'add_temperature_to_prompts'
down_revision = '9b68becb12a7'  # Point to the latest migration
branch_labels = None
depends_on = None


def upgrade():
    # Add temperature column with default value of 0.7
    op.add_column('prompts', sa.Column('temperature', sa.Float(), nullable=True, server_default='0.0'))


def downgrade():
    # Remove temperature column
    op.drop_column('prompts', 'temperature') 